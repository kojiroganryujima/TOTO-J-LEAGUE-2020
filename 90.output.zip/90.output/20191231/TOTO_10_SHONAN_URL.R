#�`�[������񁚁���
TMP_TEAM_ORIGIN <- "�Ó�"
TEAM_NAME_CONDITION <- "�Ó�x���}�[���Ó�"

game_URL <- c("https://www.football-lab.jp/shon/report/?year=2019&month=02&date=23",#1
              "https://www.football-lab.jp/shon/report/?year=2019&month=03&date=02",#2
              "https://www.football-lab.jp/shon/report/?year=2019&month=03&date=09",#3
              "https://www.football-lab.jp/shon/report/?year=2019&month=03&date=17",#4
              "https://www.football-lab.jp/shon/report/?year=2019&month=03&date=17",#5
              "https://www.football-lab.jp/shon/report/?year=2019&month=04&date=06",#6
              "https://www.football-lab.jp/shon/report/?year=2019&month=04&date=14",#7
              "https://www.football-lab.jp/shon/report/?year=2019&month=04&date=19",#8
              "https://www.football-lab.jp/shon/report/?year=2019&month=04&date=28",#9
              "https://www.football-lab.jp/shon/report/?year=2019&month=05&date=04",#10
              "https://www.football-lab.jp/shon/report/?year=2019&month=05&date=12",#11
              "https://www.football-lab.jp/shon/report/?year=2019&month=05&date=17",#12
              "https://www.football-lab.jp/shon/report/?year=2019&month=05&date=26",#13
              "https://www.football-lab.jp/shon/report/?year=2019&month=05&date=31",#14
              "https://www.football-lab.jp/shon/report/?year=2019&month=06&date=14",#15
              "https://www.football-lab.jp/shon/report/?year=2019&month=06&date=22",#16
              "https://www.football-lab.jp/shon/report/?year=2019&month=06&date=30",#17
              "https://www.football-lab.jp/shon/report/?year=2019&month=07&date=07",#18
              "https://www.football-lab.jp/shon/report/?year=2019&month=07&date=14",#19
              "https://www.football-lab.jp/shon/report/?year=2019&month=07&date=20",#20
              "https://www.football-lab.jp/shon/report/?year=2019&month=08&date=03",#21
              "https://www.football-lab.jp/shon/report/?year=2019&month=08&date=11",#22
              "https://www.football-lab.jp/shon/report/?year=2019&month=08&date=17",#23
              "https://www.football-lab.jp/shon/report/?year=2019&month=08&date=24",#24
              "https://www.football-lab.jp/shon/report/?year=2019&month=09&date=01",#25
              "https://www.football-lab.jp/shon/report/?year=2019&month=09&date=14",#26
              "https://www.football-lab.jp/shon/report/?year=2019&month=09&date=29",#27
              "https://www.football-lab.jp/shon/report/?year=2019&month=10&date=06",#28
              "https://www.football-lab.jp/shon/report/?year=2019&month=10&date=19",#29
              "https://www.football-lab.jp/shon/report/?year=2019&month=11&date=03",#30
              "https://www.football-lab.jp/shon/report/?year=2019&month=11&date=09",#31
              "https://www.football-lab.jp/shon/report/?year=2019&month=11&date=23",#32
              "https://www.football-lab.jp/shon/report/?year=2019&month=11&date=30",#33
              "https://www.football-lab.jp/shon/report/?year=2019&month=12&date=07"#34
)