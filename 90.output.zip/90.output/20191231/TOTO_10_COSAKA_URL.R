#�`�[������񁚁���
TMP_TEAM_ORIGIN <- "�b���"
TEAM_NAME_CONDITION <- "�Z���b�\���b���"

game_URL <- c("https://www.football-lab.jp/c-os/report/?year=2019&month=02&date=22",#1
              "https://www.football-lab.jp/c-os/report/?year=2019&month=03&date=02",#2
              "https://www.football-lab.jp/c-os/report/?year=2019&month=03&date=09",#3
              "https://www.football-lab.jp/c-os/report/?year=2019&month=03&date=17",#4
              "https://www.football-lab.jp/c-os/report/?year=2019&month=03&date=30",#5
              "https://www.football-lab.jp/c-os/report/?year=2019&month=04&date=05",#6
              "https://www.football-lab.jp/c-os/report/?year=2019&month=04&date=13",#7
              "https://www.football-lab.jp/c-os/report/?year=2019&month=04&date=20",#8
              "https://www.football-lab.jp/c-os/report/?year=2019&month=04&date=27",#9
              "https://www.football-lab.jp/c-os/report/?year=2019&month=05&date=04",#10
              "https://www.football-lab.jp/c-os/report/?year=2019&month=05&date=11",#1
              "https://www.football-lab.jp/c-os/report/?year=2019&month=05&date=18",#12
              "https://www.football-lab.jp/c-os/report/?year=2019&month=05&date=25",#13
              "https://www.football-lab.jp/c-os/report/?year=2019&month=06&date=01",#14
              "https://www.football-lab.jp/c-os/report/?year=2019&month=06&date=14",#15
              "https://www.football-lab.jp/c-os/report/?year=2019&month=06&date=22",#16
              "https://www.football-lab.jp/c-os/report/?year=2019&month=06&date=30",#17
              "https://www.football-lab.jp/c-os/report/?year=2019&month=07&date=06",#18
              "https://www.football-lab.jp/c-os/report/?year=2019&month=07&date=13",#19
              "https://www.football-lab.jp/c-os/report/?year=2019&month=07&date=20",#20
              "https://www.football-lab.jp/c-os/report/?year=2019&month=08&date=03",#21
              "https://www.football-lab.jp/c-os/report/?year=2019&month=08&date=11",#22
              "https://www.football-lab.jp/c-os/report/?year=2019&month=08&date=17",#23
              "https://www.football-lab.jp/c-os/report/?year=2019&month=08&date=24",#24
              "https://www.football-lab.jp/c-os/report/?year=2019&month=09&date=01",#25
              "https://www.football-lab.jp/c-os/report/?year=2019&month=09&date=13",#26
              "https://www.football-lab.jp/c-os/report/?year=2019&month=09&date=28",#27
              "https://www.football-lab.jp/c-os/report/?year=2019&month=10&date=06",#28
              "https://www.football-lab.jp/c-os/report/?year=2019&month=10&date=18",#29
              "https://www.football-lab.jp/c-os/report/?year=2019&month=11&date=02",#30
              "https://www.football-lab.jp/c-os/report/?year=2019&month=11&date=09",#31
              "https://www.football-lab.jp/c-os/report/?year=2019&month=11&date=23",#32
              "https://www.football-lab.jp/c-os/report/?year=2019&month=11&date=30",#33
              "https://www.football-lab.jp/c-os/report/?year=2019&month=12&date=07"#34
              )