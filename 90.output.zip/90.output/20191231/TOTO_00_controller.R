#�O����
##�p�b�P�[�W�ǂݍ���
install.packages("rvest", dep=TRUE)

#PATH�ݒ�
path = "C:\\Users\\noriaki.sasaki\\Documents\\TOTO"

#�ŐV�߁�����
section <- 30

#�X�N���C�s���O�����{���邩�̃t���O
scraping_flag <- 1
#scraping_flag <- 0

#�ΐ푊���5�������Ƃ̏����}�[�W���邩�ǂ����̃t���O
#opponent_five_match_flag <- 1
opponent_five_match_flag <- 0

#��͂܂Ŏ��{���邩�̃t���O
#analytics_flag <- 1
analytics_flag <- 0



###�k�C���R���T�h�[���D�y
preparation_path <- paste(path,"\\","TOTO_10_SAPPORO_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)  
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###�x�K���^���
preparation_path <- paste(path,"\\","TOTO_10_SENDAI_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###�����A���g���[�Y
#read preparation
preparation_path <- paste(path,"\\","TOTO_10_KASHIMA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###�Y�a���b�Y
preparation_path <- paste(path,"\\","TOTO_10_URAWA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###�e�b����
preparation_path <- paste(path,"\\","TOTO_10_FCTOKYO_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###���l�e�E�}���m�X
preparation_path <- paste(path,"\\","TOTO_10_FYOKOHAMA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}  
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###�Ó�x���}�[��
preparation_path <- paste(path,"\\","TOTO_10_SHONAN_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###���t�����^�[��
preparation_path <- paste(path,"\\","TOTO_10_KAWASAKI_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###���{�R��e�b
preparation_path <- paste(path,"\\","TOTO_10_MATSUMOTO_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###���É��O�����p�X
preparation_path <- paste(path,"\\","TOTO_10_NAGOYA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}  
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###�����G�X�p���X
preparation_path <- paste(path,"\\","TOTO_10_SHIMIZU_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###�W���r���֓c
preparation_path <- paste(path,"\\","TOTO_10_IWATA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###�K���o���
preparation_path <- paste(path,"\\","TOTO_10_GOSAKA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###�Z���b�\���
preparation_path <- paste(path,"\\","TOTO_10_COSAKA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###���B�b�Z���_��
preparation_path <- paste(path,"\\","TOTO_10_KOBE_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###�T���t���b�`�F�L��
preparation_path <- paste(path,"\\","TOTO_10_HIROSHIMA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###�T�K������
preparation_path <- paste(path,"\\","TOTO_10_TOSU_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###�啪�g���j�[�^
preparation_path <- paste(path,"\\","TOTO_10_OITA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}
