#�`�[������񁚁���
TMP_TEAM_ORIGIN <- "���lFM"
TEAM_NAME_CONDITION <- "���l�e�E�}���m�X���lFM"

game_URL <- c("https://www.football-lab.jp/y-fm/report/?year=2019&month=02&date=23",#1
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=03&date=02",#2
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=03&date=10",#3
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=03&date=17",#4
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=03&date=29",#5
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=04&date=05",#6
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=04&date=13",#7
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=04&date=20",#8
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=04&date=28",#9
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=05&date=03",#10
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=05&date=11",#11
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=05&date=18",#12
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=05&date=26",#13
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=05&date=31",#14
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=06&date=15",#15
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=06&date=22",#16
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=06&date=29",#17
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=07&date=06",#18
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=07&date=13",#19
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=07&date=20",#20
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=08&date=03",#21
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=08&date=10",#22
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=08&date=17",#23
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=08&date=24",#24
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=08&date=31",#25
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=09&date=14",#26
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=09&date=28",#27
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=10&date=05",#28
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=10&date=19",#29
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=11&date=02",#30
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=11&date=09",#31
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=11&date=23",#32
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=11&date=30",#33
              "https://www.football-lab.jp/y-fm/report/?year=2019&month=12&date=07"#34
              )