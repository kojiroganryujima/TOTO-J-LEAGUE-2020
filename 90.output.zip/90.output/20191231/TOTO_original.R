#����@======================================================================
#�O����
##�p�b�P�[�W�ǂݍ���
install.packages("rvest", dep=TRUE)
library(rvest)
library(rpart)
library(sys)
#source("C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\TOTO_70_matrix_functions.R")

#�����擾
DATE_TIME <- format(Sys.time(), "%Y%m%d%H%M%S")

#�S�[����������argument
dif <- 0

#�ŐV�߁�����
section <- 29

#�`�[������񁚁���
TMP_TEAM_ORIGIN <- "����"
TEAM_NAME_CONDITION <- "�����A���g���[�Y����"

#�e������i�[����}�g���N�X(�s��)���쐬
#�S�[���L�^
matrix_team <- matrix(0:0, nrow=50, ncol=10)
matrix_team_GOAL <- matrix(0:0, nrow=50, ncol=10)
matrix_team_LOST <- matrix(0:0, nrow=50, ncol=10)
matrix_team_GOAL_TIME <- matrix(0:0, nrow=50, ncol=6)
matrix_team_GOAL_TIME_NAME <- c("GOAL_0-15","GOAL_16-30","GOAL_31-45","GOAL_46-60","GOAL_61-75","GOAL_76-")
colnames(matrix_team_GOAL_TIME) <- matrix_team_GOAL_TIME_NAME
matrix_team_LOST_TIME <- matrix(0:0, nrow=50, ncol=6)
matrix_team_LOST_TIME_NAME <- c("LOST_0-15","LOST_16-30","LOST_31-45","LOST_46-60","LOST_61-75","LOST_76-")
colnames(matrix_team_LOST_TIME) <- matrix_team_LOST_TIME_NAME
#�ꎎ�����Ƃ̃S�[���W�v����
matrix_team_goal_sum <- matrix(0:0, nrow=50, ncol=2)
matrix_team_lost_sum <- matrix(0:0, nrow=50, ncol=2)
#��������
matrix_team_game_result <- matrix(0:0, nrow=50, ncol=1)
matrix_team_game_result_point <- matrix(0:0, nrow=50, ncol=1)
#5�������Ƃ̎�������
matrix_team_game_result_five_matches <- matrix(0:0, nrow=50, ncol=1)
#5�������Ƃ̎��ԑѕʓ��_�E���_
matrix_team_goal_time_sum_five_matches <- matrix(0:0, nrow=50, ncol=6)
matrix_team_lost_time_sum_five_matches <- matrix(0:0, nrow=50, ncol=6)

#�e��W�v�p�}�g���N�X�E�x�N�g��
#�S�[���W�v�p�̃x�N�g��
team_goal <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
team_lost <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
#�S�[���W�v�p�̃}�g���N�X
matrix_team_GOAL <- rbind(matrix_team, team_goal)
matrix_team_LOST <- rbind(matrix_team, team_lost)
#�S�[���������Ԃ̋L�^�x�N�g��
team_goal_time <- matrix(0:0, nrow=50, ncol=6)
team_goal_time_name <- c("0-15","16-30","31-45","46-60","61-75","76-")
colnames(team_goal_time) <- team_goal_time_name
team_lost_time <- matrix(0:0, nrow=50, ncol=6)
team_lost_time_name <- c("0-15","16-30","31-45","46-60","61-75","76-")
colnames(team_lost_time) <- team_lost_time_name

#�e�������ƂɃI�t�B�V�����T�C�g��������擾
game_URL <- c("https://www.football-lab.jp/kasm/report/?year=2019&month=02&date=23",#1
              "https://www.football-lab.jp/kasm/report/?year=2019&month=03&date=01",#2
              "https://www.football-lab.jp/kasm/report/?year=2019&month=03&date=09",#3
              "https://www.football-lab.jp/kasm/report/?year=2019&month=03&date=17",#4
              "https://www.football-lab.jp/kasm/report/?year=2019&month=03&date=30",#5
              "https://www.football-lab.jp/kasm/report/?year=2019&month=04&date=05",#6
              "https://www.football-lab.jp/kasm/report/?year=2019&month=04&date=14",#7
              "https://www.football-lab.jp/kasm/report/?year=2019&month=04&date=20",#8
              "https://www.football-lab.jp/kasm/report/?year=2019&month=04&date=28",#9
              "https://www.football-lab.jp/kasm/report/?year=2019&month=05&date=03",#10
              "https://www.football-lab.jp/kasm/report/?year=2019&month=05&date=12",#11
              "https://www.football-lab.jp/kasm/report/?year=2019&month=05&date=18",#12
              "https://www.football-lab.jp/kasm/report/?year=2019&month=05&date=26",#13
              "https://www.football-lab.jp/kasm/report/?year=2019&month=06&date=01",#14
              "https://www.football-lab.jp/kasm/report/?year=2019&month=06&date=14",#15
              "https://www.football-lab.jp/kasm/report/?year=2019&month=06&date=30",#16
              "https://www.football-lab.jp/kasm/report/?year=2019&month=07&date=06",#17
              "https://www.football-lab.jp/kasm/report/?year=2019&month=07&date=13",#18
              "https://www.football-lab.jp/kasm/report/?year=2019&month=07&date=20",#19
              "https://www.football-lab.jp/kasm/report/?year=2019&month=07&date=31",#20
              "https://www.football-lab.jp/kasm/report/?year=2019&month=08&date=03",#21
              "https://www.football-lab.jp/kasm/report/?year=2019&month=08&date=10",#22
              "https://www.football-lab.jp/kasm/report/?year=2019&month=08&date=17",#23
              "https://www.football-lab.jp/kasm/report/?year=2019&month=08&date=23",#24
              "https://www.football-lab.jp/kasm/report/?year=2019&month=09&date=01",#25
              "https://www.football-lab.jp/kasm/report/?year=2019&month=09&date=14",#26
              "https://www.football-lab.jp/kasm/report/?year=2019&month=09&date=28",#27
              "https://www.football-lab.jp/kasm/report/?year=2019&month=10&date=06",#28
              "https://www.football-lab.jp/kasm/report/?year=2019&month=10&date=18"#29
              #"",#30
              #"",#31
              #"",#32
              #"",#33
              )


library(rvest)


#�����J�n===============================================================================
#�Q�[�����
for(k in 1:section){
  
  #�S�[�������i�[����x�N�g����������
  TMP_HOME_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
  TMP_AWAY_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
  HOME_GOAL_LIST <- c("")
  AWAY_GOAL_LIST <- c("")
  HOME_GOAL_LIST <- as.integer(HOME_GOAL_LIST)
  AWAY_GOAL_LIST <- as.integer(AWAY_GOAL_LIST)
  HOME_GOAL_INT <- c("")
  AWAY_GOAL_INT <- c("")
  HOME_GOAL_INT <- as.integer(HOME_GOAL_INT)
  AWAY_GOAL_INT <- as.integer(AWAY_GOAL_INT)
  HOME_GOAL_TMP <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
  AWAY_GOAL_TMP <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
  HOME_GOAL <- c("")
  AWAY_GOAL <- c("")
  HOME_GOAL <- as.integer(HOME_GOAL_INT)
  AWAY_GOAL <- as.integer(AWAY_GOAL_INT)
  
  #recall_html <- read_html("https://www.football-lab.jp/kasm/report/?year=2019&month=02&date=23")  #�f�o�b�O�p��
  recall_html <- read_html(game_URL[k])
  
  #�S�[���ƃS�[�������v���[���[�����擾
  recall_html %>%
    html_nodes(".tblCompare") %>%
    html_text() -> home_away_team  # �e�L�X�g�f�[�^�����o��
  write.csv(home_away_team,"C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_origin_team_.csv", quote=F, col.names=F, append=T)
  read.csv("C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_origin_team_.csv", header=FALSE) -> TMP_team_home_away_updated
  comparative_home_away <- as.character(TMP_team_home_away_updated[4,1])
  comparative_home_away <- gsub("\t","",comparative_home_away)
  
  #���z�[���Q�[���������̂��A�A�E�F�C�Q�[���������̂��m�F���邽�߂̏����擾
  if(TEAM_NAME_CONDITION == comparative_home_away){
    game_kind <- "home"
  }else{
    game_kind <- "away"
  }
  
  #�S�[�����Ԃ̃C���v�b�g
  #scraping("//div[@class='lineTbl']/table/tr/td[position()=3]",matrix_goal_time)
  recall_html %>%
    html_nodes(xpath = "//div[@class='lineTbl']/table/tr/td[position()=3]") %>%
    html_text() -> matrix_goal_time  # �e�L�X�g�f�[�^�����o��
  #write.csv(matrix_goal_time[1],"C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_goal_time.csv", quote=F, col.names=F, append=T)
  #read.csv("C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_goal_time.csv", header=FALSE) -> TMP_goal_time

  #Web�T�C�g�����L�ڃ`�[���̃S�[���C���v�b�g
  #scraping("//div[@class='lineTbl']/table/tr/td[@class='name r']",matrix_leftside_goal)
  recall_html %>%
    html_nodes(xpath = "//div[@class='lineTbl']/table/tr/td[@class='name r']") %>%
    html_text() -> matrix_leftside_goal  # �e�L�X�g�f�[�^�����o��
  
  #write.csv(matrix_leftside_goal[1],"C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_leftside_goal_score.csv", quote=F, col.names=F, append=T)
  #read.csv("C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_leftside_goal_score.csv", header=FALSE) -> TMP_leftside_goal_updated
  
  #Web�T�C�g�E���L�ڃ`�[���̃S�[���C���v�b�g
  #scraping("//div/table/tr/td[@class='name l']",matrix_rightside_goal)
  recall_html %>%
    html_nodes(xpath = "//div/table/tr/td[@class='name l']") %>%
    html_text() -> matrix_rightside_goal  # �e�L�X�g�f�[�^�����o��
  #write.csv(matrix_rightside_goal,"C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_rightside_goal_score.csv", quote=F, col.names=F, append=T)
  #read.csv("C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_rightside_goal_score.csv", header=FALSE) -> TMP_rightside_goal_updated
  
  #�S�[�����ƃS�[�������v���[���[�̏����x�N�g���֊i�[
  goal_num <- length(matrix_goal_time)
  for(i in 1:goal_num){
    if(game_kind == "home"){
      #HOME
      tmp_na_check <- as.character(matrix_leftside_goal[i])
      if(tmp_na_check == ""){
      }else{
        #goalTimeUpdate(TMP_HOME_GOAL[i],matrix_goal_time[i],HOME_GOAL[i])
        TMP_HOME_GOAL[i] <- matrix_goal_time[i]
        HOME_GOAL_INT[i] <- substr(TMP_HOME_GOAL[i], 3, nchar(TMP_HOME_GOAL[i])-1)
        HOME_GOAL_INT[i] <- as.integer(HOME_GOAL_INT[i])
        #goalTimeFix(HOME_GOAL[i],dif)
        tmp_prefix <- substr(TMP_HOME_GOAL[i],1,2)
        if(tmp_prefix == "�O��"){
          dif <- 0
        }else{
          dif <- 45
        }
        HOME_GOAL_TMP[i] <- as.integer(as.integer(HOME_GOAL_INT[i]) + dif)
      }
      #AWAY(Oppenent Goal)
      tmp_na_check <- as.character(matrix_rightside_goal[i])
      if(tmp_na_check == ""){
      }else{
        #goalTimeUpdate(TMP_AWAY_GOAL[i],matrix_goal_time[i],AWAY_GOAL[i])
        TMP_AWAY_GOAL[i] <- matrix_goal_time[i]
        AWAY_GOAL_INT[i] <- substr(TMP_AWAY_GOAL[i], 3, nchar(TMP_AWAY_GOAL[i])-1)
        AWAY_GOAL_INT[i] <- as.integer(AWAY_GOAL_INT[i])
        #goalTimeFix(HOME_GOAL[i],dif)
        tmp_prefix <- substr(TMP_AWAY_GOAL[i],1,2)
        if(tmp_prefix == "�O��"){
          dif <- 0
        }else{
          dif <- 45
        }
        AWAY_GOAL_TMP[i] <- as.integer(as.integer(AWAY_GOAL_INT[i]) + dif)
      }
    }else{
      #AWAY
      tmp_na_check <- as.character(matrix_rightside_goal[i])
      if(tmp_na_check == ""){
      }else{
        #goalTimeUpdate(TMP_AWAY_GOAL[i],matrix_goal_time[i],AWAY_GOAL[i])
        TMP_AWAY_GOAL[i] <- matrix_goal_time[i]
        AWAY_GOAL_INT[i] <- substr(TMP_AWAY_GOAL[i], 3, nchar(TMP_AWAY_GOAL[i])-1)
        AWAY_GOAL_INT[i] <- as.integer(AWAY_GOAL_INT[i])
        #goalTimeFix(HOME_GOAL[i],dif)
        tmp_prefix <- substr(TMP_AWAY_GOAL[i],1,2)
        if(tmp_prefix == "�O��"){
          dif <- 0
        }else{
          dif <- 45
        }
        AWAY_GOAL_TMP[i] <- as.integer(as.integer(AWAY_GOAL_INT[i]) + dif)
      }
      #HOME(Oppenent Goal)
      tmp_na_check <- as.character(matrix_leftside_goal[i])
      if(tmp_na_check == ""){
      }else{
        #goalTimeUpdate(TMP_HOME_GOAL[i],matrix_goal_time[i],HOME_GOAL[i])
        TMP_HOME_GOAL[i] <- matrix_goal_time[i]
        HOME_GOAL_INT[i] <- substr(TMP_HOME_GOAL[i], 3, nchar(TMP_HOME_GOAL[i])-1)
        HOME_GOAL_INT[i] <- as.integer(HOME_GOAL_INT[i])
        #goalTimeFix(HOME_GOAL[i],dif)
        tmp_prefix <- substr(TMP_HOME_GOAL[i],1,2)
        if(tmp_prefix == "�O��"){
          dif <- 0
        }else{
          dif <- 45
        }
        HOME_GOAL_TMP[i] <- as.integer(as.integer(HOME_GOAL_INT[i]) + dif)
        
      }
    }
  }
  
  #�e�S�[�������ԑѕʂɃ}�g���N�X�֊i�[
  h <- 1
  for(l in HOME_GOAL_TMP){
    if(is.na(l)){
    }else{
      #print(l)
      HOME_GOAL[h] = l
      h <- h + 1
    }
  }
  
  h = h -1

  a <- 1
  for(l in AWAY_GOAL_TMP){
    if(is.na(l)){
    }else{
      #print(l)
      AWAY_GOAL[a] = l
      a <- a + 1
    }
  }
  
  a = a -1

  if(game_kind == "home"){
    if( h > 0){
      for(l in 1:h){
        #HOME GOAL COUNT
        #putGoalToMatrix(HOME_GOAL[l],team_goal_time[k,1],0,15)
        #putGoalToMatrix(HOME_GOAL[l],team_goal_time[k,1],15,30)
        #putGoalToMatrix(HOME_GOAL[l],team_goal_time[k,1],30,45)
        #putGoalToMatrix(HOME_GOAL[l],team_goal_time[k,1],45,60)
        #putGoalToMatrix(HOME_GOAL[l],team_goal_time[k,1],60,75)
        #if(HOME_GOAL[l] > 76){
        #  team_goal_time[k,6] <- team_goal_time[k,6] +1
        #}
        if((15 >= HOME_GOAL[l]) && (HOME_GOAL[l]>= 0)){
          team_goal_time[k,1] <- team_goal_time[k,1] +1
        }
        if((30 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 15)){
          team_goal_time[k,2] <- team_goal_time[k,2] +1
        }
        if((45 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 30)){
          team_goal_time[k,3] <- team_goal_time[k,3] +1
        }
        if((60 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 45)){
          team_goal_time[k,4] <- team_goal_time[k,4] +1
        }
        if((75 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 60)){
          team_goal_time[k,5] <- team_goal_time[k,5] +1
        }
        if(HOME_GOAL[l] >= 76){
          team_goal_time[k,6] <- team_goal_time[k,6] +1
        }
      }
    }

    if( a > 0){
      #Opponent GOAL COUNT
      for(l in 1:a){
        #putGoalToMatrix(AWAY_GOAL[l],team_lost_time[k,1],0,15)
        #putGoalToMatrix(AWAY_GOAL[l],team_lost_time[k,1],15,30)
        #putGoalToMatrix(AWAY_GOAL[l],team_lost_time[k,1],30,45)
        #putGoalToMatrix(AWAY_GOAL[l],team_lost_time[k,1],45,60)
        #putGoalToMatrix(AWAY_GOAL[l],team_lost_time[k,1],60,75)
        #if(AWAY_GOAL[l] >76){
        #  team_lost_time[k,6] <- team_lost_time[k,6] +1
        #}
        if((15 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] >= 0)){
          team_lost_time[k,1] <- team_lost_time[k,1] +1
        }
        if((30 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 15)){
          team_lost_time[k,2] <- team_lost_time[k,2] +1
        }
        if((45 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 30)){
          team_lost_time[k,3] <- team_lost_time[k,3] +1
        }
        if((60 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 45)){
          team_lost_time[k,4] <- team_lost_time[k,4] +1
        }
        if((75 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 60)){
          team_lost_time[k,5] <- team_lost_time[k,5] +1
        }
        if(AWAY_GOAL[l] >= 76){
          team_lost_time[k,6] <- team_lost_time[k,6] +1
        }
      }
    }
    
  }else{
    if( a > 0){
      for(l in 1:a){
        #AWAY GOAL COUNT
        if( (15 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] >= 0)){
          team_goal_time[k,1] <- team_goal_time[k,1] +1
        }
        if(( 30 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 15)){
          team_goal_time[k,2] <- team_goal_time[k,2] +1
        }
        if(( 45 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 30)){
          team_goal_time[k,3] <- team_goal_time[k,3] +1
        }
        if(( 60 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 45)){
          team_goal_time[k,4] <- team_goal_time[k,4] +1
        }
        if(( 75 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 60)){
          team_goal_time[k,5] <- team_goal_time[k,5] +1
        }
        if(AWAY_GOAL[l] >= 76){
          team_goal_time[k,6] <- team_goal_time[k,6] +1
        }
      }
    }
    #Opponent GOAL COUNT
    if( h > 0){
      for(l in 1:h){
        if( (15 >= HOME_GOAL[l]) && (HOME_GOAL[l] >= 0)){
          team_lost_time[k,1] <- team_lost_time[k,1] +1
        }
        if(( 30 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 15)){
          team_lost_time[k,2] <- team_lost_time[k,2] +1
        }
        if(( 45 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 30)){
          team_lost_time[k,3] <- team_lost_time[k,3] +1
        }
        if(( 60 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 45)){
          team_lost_time[k,4] <- team_lost_time[k,4] +1
        }
        if(( 75 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 60)){
          team_lost_time[k,5] <- team_lost_time[k,5] +1
        }
        if(HOME_GOAL[l] >= 76){
          team_lost_time[k,6] <- team_lost_time[k,6] +1
        }
      }
    }
  }
}



#���L���X�g���āI�I
#�e�߂̃S�[�����v
matrix_team_GOAL_SUM_NAME <- c("GOAL_SUM","hogehoge")
colnames(matrix_team_goal_sum) <- matrix_team_GOAL_SUM_NAME
for(m in 1:section){
  matrix_team_goal_sum[m] <- team_goal_time[m,1] + team_goal_time[m,2] + team_goal_time[m,3] + team_goal_time[m,4] + team_goal_time[m,5] + team_goal_time[m,6]
  matrix_team_lost_sum[m] <- team_lost_time[m,1] + team_lost_time[m,2] + team_lost_time[m,3] + team_lost_time[m,4] + team_lost_time[m,5] + team_lost_time[m,6]
}

#�e�߂̏����_�����}�g���N�X�֊i�[
matrix_team_GAME_RESULT_NAME <- c("GAME_RESULT")
colnames(matrix_team_game_result) <- matrix_team_GAME_RESULT_NAME
matrix_team_GAME_RESULT_POINT_NAME <- c("GAME_RESULT_POINT")
colnames(matrix_team_game_result_point) <- matrix_team_GAME_RESULT_POINT_NAME
for(n in 1:section){
  
  diff_point <- matrix_team_goal_sum[n] - matrix_team_lost_sum[n]
  
  if(diff_point > 0){
    matrix_team_game_result[n] <- "�Z"
    matrix_team_game_result_point[n] <- 3
  }
  if(diff_point < 0){
    matrix_team_game_result[n] <- "�~"
    matrix_team_game_result_point[n] <- 0
  }
  if(diff_point == 0){
    matrix_team_game_result[n] <- "��"
    matrix_team_game_result_point[n] <- 1
  }
}

#5�ߖ��̊e������i�[
#5�ߖ��̏����_���
matrix_team_RESULT_FIVE_MATCHES_NAME <- c("RESULT_FIVE_MATCHES_NAME")
colnames(matrix_team_game_result_five_matches) <- matrix_team_RESULT_FIVE_MATCHES_NAME

for(o in 1:section){
  
  if(o == 1){
    matrix_team_game_result_five_matches[o] <- matrix_team_game_result_point[o]
  }
  if(o == 2){
    matrix_team_game_result_five_matches[o] <- matrix_team_game_result_point[1] + matrix_team_game_result_point[o]
  }
  if(o == 3){
    matrix_team_game_result_five_matches[o] <- matrix_team_game_result_point[1] + matrix_team_game_result_point[2] + matrix_team_game_result_point[o]
  }
  if(o == 4){
    matrix_team_game_result_five_matches[o] <- matrix_team_game_result_point[1] + matrix_team_game_result_point[2] + matrix_team_game_result_point[3] + matrix_team_game_result_point[o]
  }
  if(o >= 5){
    matrix_team_game_result_five_matches[o] <- matrix_team_game_result_point[o-1] + matrix_team_game_result_point[o-2] + matrix_team_game_result_point[o-3] + matrix_team_game_result_point[o-4] + matrix_team_game_result_point[o]
  }
}

#5�������̎��ԑѕʓ��_�E���_
#���_
matrix_team_GOAL_FIVE_MATCHES_NAME <- c("S_F_M_GOAL_N_1-15","S_F_M_GOAL_N_16-30","S_F_M_GOAL_N_31-45","S_F_M_GOAL_N_45-60","S_F_M_GOAL_N_61-75","S_F_M_GOAL_N_76-90")
colnames(matrix_team_goal_time_sum_five_matches) <- matrix_team_GOAL_FIVE_MATCHES_NAME

for(p in 1:section){
  if(p == 1){
    matrix_team_goal_time_sum_five_matches[p,1] <- team_goal_time[p,1]
    matrix_team_goal_time_sum_five_matches[p,2] <- team_goal_time[p,2]
    matrix_team_goal_time_sum_five_matches[p,3] <- team_goal_time[p,3]
    matrix_team_goal_time_sum_five_matches[p,4] <- team_goal_time[p,4]
    matrix_team_goal_time_sum_five_matches[p,5] <- team_goal_time[p,5]
    matrix_team_goal_time_sum_five_matches[p,6] <- team_goal_time[p,6]
  }
  if(p == 2){
    matrix_team_goal_time_sum_five_matches[p,1] <- team_goal_time[p,1] + team_goal_time[1,1]
    matrix_team_goal_time_sum_five_matches[p,2] <- team_goal_time[p,2] + team_goal_time[1,2]
    matrix_team_goal_time_sum_five_matches[p,3] <- team_goal_time[p,3] + team_goal_time[1,3]
    matrix_team_goal_time_sum_five_matches[p,4] <- team_goal_time[p,4] + team_goal_time[1,4]
    matrix_team_goal_time_sum_five_matches[p,5] <- team_goal_time[p,5] + team_goal_time[1,5]
    matrix_team_goal_time_sum_five_matches[p,6] <- team_goal_time[p,6] + team_goal_time[1,6]
  }
  if(p == 3){
    matrix_team_goal_time_sum_five_matches[p,1] <- team_goal_time[p,1] + team_goal_time[2,1] + team_goal_time[1,1]
    matrix_team_goal_time_sum_five_matches[p,2] <- team_goal_time[p,2] + team_goal_time[2,2] + team_goal_time[1,2]
    matrix_team_goal_time_sum_five_matches[p,3] <- team_goal_time[p,3] + team_goal_time[2,3] + team_goal_time[1,3]
    matrix_team_goal_time_sum_five_matches[p,4] <- team_goal_time[p,4] + team_goal_time[2,4] + team_goal_time[1,4]
    matrix_team_goal_time_sum_five_matches[p,5] <- team_goal_time[p,5] + team_goal_time[2,5] + team_goal_time[1,5]
    matrix_team_goal_time_sum_five_matches[p,6] <- team_goal_time[p,6] + team_goal_time[2,6] + team_goal_time[1,6]
  }
  if(p == 4){
    matrix_team_goal_time_sum_five_matches[p,1] <- team_goal_time[p,1] + team_goal_time[3,1] + team_goal_time[2,1] + team_goal_time[1,1]
    matrix_team_goal_time_sum_five_matches[p,2] <- team_goal_time[p,2] + team_goal_time[3,2] + team_goal_time[2,2] + team_goal_time[1,2]
    matrix_team_goal_time_sum_five_matches[p,3] <- team_goal_time[p,3] + team_goal_time[3,3] + team_goal_time[2,3] + team_goal_time[1,3]
    matrix_team_goal_time_sum_five_matches[p,4] <- team_goal_time[p,4] + team_goal_time[3,4] + team_goal_time[2,4] + team_goal_time[1,4]
    matrix_team_goal_time_sum_five_matches[p,5] <- team_goal_time[p,5] + team_goal_time[3,5] + team_goal_time[2,5] + team_goal_time[1,5]
    matrix_team_goal_time_sum_five_matches[p,6] <- team_goal_time[p,6] + team_goal_time[3,6] + team_goal_time[2,6] + team_goal_time[1,6]
  }
  if(p >= 5){
    matrix_team_goal_time_sum_five_matches[p,1] <- team_goal_time[p,1] + team_goal_time[4,1] + team_goal_time[3,1] + team_goal_time[2,1] + team_goal_time[1,1]
    matrix_team_goal_time_sum_five_matches[p,2] <- team_goal_time[p,2] + team_goal_time[4,2] + team_goal_time[3,2] + team_goal_time[2,2] + team_goal_time[1,2]
    matrix_team_goal_time_sum_five_matches[p,3] <- team_goal_time[p,3] + team_goal_time[4,3] + team_goal_time[3,3] + team_goal_time[2,3] + team_goal_time[1,3]
    matrix_team_goal_time_sum_five_matches[p,4] <- team_goal_time[p,4] + team_goal_time[4,4] + team_goal_time[3,4] + team_goal_time[2,4] + team_goal_time[1,4]
    matrix_team_goal_time_sum_five_matches[p,5] <- team_goal_time[p,5] + team_goal_time[4,5] + team_goal_time[3,5] + team_goal_time[2,5] + team_goal_time[1,5]
    matrix_team_goal_time_sum_five_matches[p,6] <- team_goal_time[p,6] + team_goal_time[4,6] + team_goal_time[3,6] + team_goal_time[2,6] + team_goal_time[1,6]
  }
}

#���_
matrix_team_LOST_FIVE_MATCHES_NAME <- c("S_F_M_LOST_N_1-15","S_F_M_LOST_N_16-30","S_F_M_LOST_N_31-45","S_F_M_LOST_N_45-60","S_F_M_LOST_N_61-75","S_F_M_LOST_N_76-90")
colnames(matrix_team_lost_time_sum_five_matches) <- matrix_team_LOST_FIVE_MATCHES_NAME

for(q in 1:section){
  if(q == 1){
    matrix_team_lost_time_sum_five_matches[q,1] <- team_lost_time[q,1]
    matrix_team_lost_time_sum_five_matches[q,2] <- team_lost_time[q,2]
    matrix_team_lost_time_sum_five_matches[q,3] <- team_lost_time[q,3]
    matrix_team_lost_time_sum_five_matches[q,4] <- team_lost_time[q,4]
    matrix_team_lost_time_sum_five_matches[q,5] <- team_lost_time[q,5]
    matrix_team_lost_time_sum_five_matches[q,6] <- team_lost_time[q,6]
  }
  if(q == 2){
    matrix_team_lost_time_sum_five_matches[q,1] <- team_lost_time[q,1] + team_lost_time[1,1]
    matrix_team_lost_time_sum_five_matches[q,2] <- team_lost_time[q,2] + team_lost_time[1,2]
    matrix_team_lost_time_sum_five_matches[q,3] <- team_lost_time[q,3] + team_lost_time[1,3]
    matrix_team_lost_time_sum_five_matches[q,4] <- team_lost_time[q,4] + team_lost_time[1,4]
    matrix_team_lost_time_sum_five_matches[q,5] <- team_lost_time[q,5] + team_lost_time[1,5]
    matrix_team_lost_time_sum_five_matches[q,6] <- team_lost_time[q,6] + team_lost_time[1,6]
  }
  if(q == 3){
    matrix_team_lost_time_sum_five_matches[q,1] <- team_lost_time[q,1] + team_lost_time[2,1] + team_lost_time[1,1]
    matrix_team_lost_time_sum_five_matches[q,2] <- team_lost_time[q,2] + team_lost_time[2,2] + team_lost_time[1,2]
    matrix_team_lost_time_sum_five_matches[q,3] <- team_lost_time[q,3] + team_lost_time[2,3] + team_lost_time[1,3]
    matrix_team_lost_time_sum_five_matches[q,4] <- team_lost_time[q,4] + team_lost_time[2,4] + team_lost_time[1,4]
    matrix_team_lost_time_sum_five_matches[q,5] <- team_lost_time[q,5] + team_lost_time[2,5] + team_lost_time[1,5]
    matrix_team_lost_time_sum_five_matches[q,6] <- team_lost_time[q,6] + team_lost_time[2,6] + team_lost_time[1,6]
  }
  if(q == 4){
    matrix_team_lost_time_sum_five_matches[q,1] <- team_lost_time[q,1] + team_lost_time[3,1] + team_lost_time[2,1] + team_lost_time[1,1]
    matrix_team_lost_time_sum_five_matches[q,2] <- team_lost_time[q,2] + team_lost_time[3,2] + team_lost_time[2,2] + team_lost_time[1,2]
    matrix_team_lost_time_sum_five_matches[q,3] <- team_lost_time[q,3] + team_lost_time[3,3] + team_lost_time[2,3] + team_lost_time[1,3]
    matrix_team_lost_time_sum_five_matches[q,4] <- team_lost_time[q,4] + team_lost_time[3,4] + team_lost_time[2,4] + team_lost_time[1,4]
    matrix_team_lost_time_sum_five_matches[q,5] <- team_lost_time[q,5] + team_lost_time[3,5] + team_lost_time[2,5] + team_lost_time[1,5]
    matrix_team_lost_time_sum_five_matches[q,6] <- team_lost_time[q,6] + team_lost_time[3,6] + team_lost_time[2,6] + team_lost_time[1,6]
  }
  if(q >= 5){
    matrix_team_lost_time_sum_five_matches[q,1] <- team_lost_time[q,1] + team_lost_time[4,1] + team_lost_time[3,1] + team_lost_time[2,1] + team_lost_time[1,1]
    matrix_team_lost_time_sum_five_matches[q,2] <- team_lost_time[q,2] + team_lost_time[4,2] + team_lost_time[3,2] + team_lost_time[2,2] + team_lost_time[1,2]
    matrix_team_lost_time_sum_five_matches[q,3] <- team_lost_time[q,3] + team_lost_time[4,3] + team_lost_time[3,3] + team_lost_time[2,3] + team_lost_time[1,3]
    matrix_team_lost_time_sum_five_matches[q,4] <- team_lost_time[q,4] + team_lost_time[4,4] + team_lost_time[3,4] + team_lost_time[2,4] + team_lost_time[1,4]
    matrix_team_lost_time_sum_five_matches[q,5] <- team_lost_time[q,5] + team_lost_time[4,5] + team_lost_time[3,5] + team_lost_time[2,5] + team_lost_time[1,5]
    matrix_team_lost_time_sum_five_matches[q,6] <- team_lost_time[q,6] + team_lost_time[4,6] + team_lost_time[3,6] + team_lost_time[2,6] + team_lost_time[1,6]
  }
}


#matrix_team <- rbind(matrix_team, HOME_GOAL[i])
#���ԑт��Ƃ̓��_�E���_
matrix_team_time <- cbind(team_goal_time, team_lost_time)
#���s���ʒǉ�
matrix_team_game_result <- cbind(matrix_team_time,matrix_team_game_result)
#5�������Ƃ̏����_�ǉ�
matrix_team_all_time_result_five <- cbind(matrix_team_game_result, matrix_team_game_result_five_matches)
#5�������Ƃ̓��_�ǉ�
matrix_team_all_time_result_five_goal <- cbind(matrix_team_all_time_result_five, matrix_team_goal_time_sum_five_matches)
#5�������Ƃ̓��_���_
matrix_team_all_time_result_five_goal_lost <- cbind(matrix_team_all_time_result_five_goal, matrix_team_lost_time_sum_five_matches)

csv_name <- paste("C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_matrix_team_all_time_result_five_goal_lost_",TMP_TEAM_ORIGIN,"_",DATE_TIME,".csv",sep="")
write.csv(matrix_team_all_time_result_five_goal_lost,csv_name, quote=F, col.names=F, append=T)

#����ؕ���
#rpartmodel = rpart(BUY_INSURANCE ~ ., data = customers)
matrix_team_all_time_result_five_frame <- as.data.frame(matrix_team_all_time_result_five_goal_lost)
#target_team <- matrix_team_all_time_result_five_frame
rpartmodel = rpart(GAME_RESULT ~ ., data = matrix_team_all_time_result_five_frame)
rpartmodel_extracted <- matrix_team_all_time_result_five_frame[1:27,]
rpartmodel = rpart(GAME_RESULT ~ ., data = rpartmodel_extracted)

#model = rpart(BUY_INSURANCE ~ ., data = customers[,-1:-7])
#model = rpart(BUY_INSURANCE ~ ., data = customers[,-1:-7], control = rpart.control(maxdepth = 4))
install.packages("rpart.plot")
library(rpart.plot)
rpart.plot(rpartmodel, extra = 4)



###����֐�
#�X�N���C�s���O
scraping <- function(x,y){
  recall_html %>%
    html_nodes(xpath = x) %>%
    html_text() -> y  # �e�L�X�g�f�[�^�����o��
}

#�S�[�����Ԃ̃A�b�v�f�[�g
goallTimeUpdate <- function(x,y,z){
  x <- y
  z <- substr(x, 3, lengh(x))
  z <- as.integer(z)
  goalTimeFix(z,dif)
  z <- z + dif
}

#�S�[�����Ԃ̏C��
goalTimeFix <- function(x,y) {
  tmp_prefix <- substr(x,1,2)
  if(tmp_prefix == "�O��"){
    y <- 0
  }else{
    y <- 45
  }
}

#�e�S�[�������ԑѕʂɃ}�g���N�X�֊i�[
putGoalToMatrix <- function(x,y,z,��)
  if((Z >= X) && (X >= ��)){
  y <- y +1
}
