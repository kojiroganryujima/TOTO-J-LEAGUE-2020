#�`�[������񁚁���
TMP_TEAM_ORIGIN <- "�f���"
TEAM_NAME_CONDITION <- "�K���o���f���"

game_URL <- c("https://www.football-lab.jp/g-os/report/?year=2019&month=02&date=23",#1
              "https://www.football-lab.jp/g-os/report/?year=2019&month=03&date=02",#2
              "https://www.football-lab.jp/g-os/report/?year=2019&month=03&date=09",#3
              "https://www.football-lab.jp/g-os/report/?year=2019&month=03&date=17",#4
              "https://www.football-lab.jp/g-os/report/?year=2019&month=03&date=30",#5
              "https://www.football-lab.jp/g-os/report/?year=2019&month=04&date=06",#6
              "https://www.football-lab.jp/g-os/report/?year=2019&month=04&date=14",#7
              "https://www.football-lab.jp/g-os/report/?year=2019&month=04&date=20",#8
              "https://www.football-lab.jp/g-os/report/?year=2019&month=04&date=28",#9
              "https://www.football-lab.jp/g-os/report/?year=2019&month=05&date=04",#10
              "https://www.football-lab.jp/g-os/report/?year=2019&month=05&date=11",#11
              "https://www.football-lab.jp/g-os/report/?year=2019&month=05&date=18",#12
              "https://www.football-lab.jp/g-os/report/?year=2019&month=05&date=25",#13
              "https://www.football-lab.jp/g-os/report/?year=2019&month=06&date=01",#14
              "https://www.football-lab.jp/g-os/report/?year=2019&month=06&date=15",#15
              "https://www.football-lab.jp/g-os/report/?year=2019&month=06&date=22",#16
              "https://www.football-lab.jp/g-os/report/?year=2019&month=06&date=29",#17
              "https://www.football-lab.jp/g-os/report/?year=2019&month=07&date=07",#18
              "https://www.football-lab.jp/g-os/report/?year=2019&month=07&date=13",#19
              "https://www.football-lab.jp/g-os/report/?year=2019&month=07&date=20",#20
              "https://www.football-lab.jp/g-os/report/?year=2019&month=08&date=02",#21
              "https://www.football-lab.jp/g-os/report/?year=2019&month=08&date=10",#22
              "https://www.football-lab.jp/g-os/report/?year=2019&month=08&date=18",#23
              "https://www.football-lab.jp/g-os/report/?year=2019&month=08&date=23",#24
              "https://www.football-lab.jp/g-os/report/?year=2019&month=08&date=31",#25
              "https://www.football-lab.jp/g-os/report/?year=2019&month=09&date=14",#26
              "https://www.football-lab.jp/g-os/report/?year=2019&month=09&date=28",#27
              "https://www.football-lab.jp/g-os/report/?year=2019&month=10&date=04",#28
              "https://www.football-lab.jp/g-os/report/?year=2019&month=10&date=19",#29
              "https://www.football-lab.jp/g-os/report/?year=2019&month=11&date=03",#30
              "https://www.football-lab.jp/g-os/report/?year=2019&month=11&date=10",#31
              "https://www.football-lab.jp/g-os/report/?year=2019&month=11&date=23",#32
              "https://www.football-lab.jp/g-os/report/?year=2019&month=11&date=30",#33
              "https://www.football-lab.jp/g-os/report/?year=2019&month=12&date=07"#34
              )