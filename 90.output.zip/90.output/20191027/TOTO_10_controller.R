#PATH
path = "C:\\Users\\noriaki.sasaki\\Documents\\TOTO"
  
#read packages
read_packages <- paste(path,"\\","TOTO_20_read_package.R",sep="")
source(read_packages)

#for J League
#read_input_variale
read_input_variale <- paste(path,"\\","TOTO_20_read_variable.R",sep="")
source(read_input_variale)

#read_input_URL
read_input_URL <- paste(path,"\\","TOTO_30_read_input_URL.R",sep="")
source(read_input_URL)

#read_allocate
read_allocate_URL <- paste(path,"\\","TOTO_40_read_allocate_URL.R",sep="")
source(read_allocate_URL)

#update matrix
read_update_matrix <- paste(path,"\\","TOTO_50_matrix_update.R",sep="")
source(read_update_matrix)