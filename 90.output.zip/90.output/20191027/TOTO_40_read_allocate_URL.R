num_element_url = length(URL_LIST_Category)

for(j in 1:num_element_url){
  ###�ǂݍ���HTML����"class=".child""�̍��ڂ̂ݒ��o���A�i�[
  paste("matchTable_node_tmp_name_",seg_start,"-",seg_end,"_",DATE,sep="") -> TMP_NODE_TABLE_NAME
  assign(paste(TMP_NODE_TABLE_NAME),html_nodes(get(URL_LIST_Category[[j]]),param))
  
  ###�ǂݍ���HTML�f�[�^(���o��)���e�[�u���`���Ŋi�[
  paste("gameTable_node_tmp_name_",seg_start,"-",seg_end,"_",DATE,sep="") -> TMP_HTML_TABLE_NAME
  assign(paste(TMP_HTML_TABLE_NAME),html_table(get(TMP_NODE_TABLE_NAME), fill=TRUE))

  num_element = 9*length(team)
  
  #1�y�[�W���̏����i�[
  for(k in 1:num_element){
    
    #target record
    get(TMP_HTML_TABLE_NAME)[[k]]$X1 -> TMP_CONTENTS_PLACE_MATCH
    
    #Team Name
    if(k < 10){
      team[[1]] -> TMP_CONTENTS_HOME_NAME
    }

    if((9 < k) && (k < 19)){
      team[[2]] -> TMP_CONTENTS_HOME_NAME
    }
    
    if((18 < k) && (k < 28)){
      team[[3]] -> TMP_CONTENTS_HOME_NAME
    }
    
    if((27 < k) && (k < 37)){
      team[[4]] -> TMP_CONTENTS_HOME_NAME
    }
    
    if((36 < k) && (k < 46)){
      team[[5]] -> TMP_CONTENTS_HOME_NAME
    }
    
    if((45 < k) && (k < 55)){
      team[[6]] -> TMP_CONTENTS_HOME_NAME
    }
    
    if((54 < k) && (k < 64)){
      team[[7]] -> TMP_CONTENTS_HOME_NAME
    }
    
    if((63 < k) && (k < 73)){
      team[[8]] -> TMP_CONTENTS_HOME_NAME
    }
    
    if((72 < k) && (k < 82)){
      team[[9]] -> TMP_CONTENTS_HOME_NAME
    }
    
    if((81 < k) && (k < 91)){
      team[[10]] -> TMP_CONTENTS_HOME_NAME
    }
    
    if((90 < k) && (k < 100)){
      team[[11]] -> TMP_CONTENTS_HOME_NAME
    }
    
    if((99 < k) && (k < 109)){
      team[[12]] -> TMP_CONTENTS_HOME_NAME
    }
    
    if((108 < k) && (k < 118)){
      team[[13]] -> TMP_CONTENTS_HOME_NAME
    }
    
    if((117 < k) && (k < 127)){
      team[[14]] -> TMP_CONTENTS_HOME_NAME
    }
    
    if((126 < k) && (k < 136)){
      team[[15]] -> TMP_CONTENTS_HOME_NAME
    }
    
    if((135 < k) && (k < 145)){
      team[[16]] -> TMP_CONTENTS_HOME_NAME
    }
    
    if((144 < k) && (k < 154)){
      team[[17]] -> TMP_CONTENTS_HOME_NAME
    }

    if((153 < k) && (k < 163)){
      team[[18]] -> TMP_CONTENTS_HOME_NAME
    }
    
    if((162 < k) && (k < 172)){
      team[[19]] -> TMP_CONTENTS_HOME_NAME
    }
      
    if((171 < k) && (k < 181)){
      team[[20]] -> TMP_CONTENTS_HOME_NAME
    }
    
    if((180 < k) && (k < 190)){
      team[[21]] -> TMP_CONTENTS_HOME_NAME
    }
    if((189 < k) && (k < 199)){
      team[[22]] -> TMP_CONTENTS_HOME_NAME
    }

    #HOME/AWAY
    get(TMP_HTML_TABLE_NAME)[[k]]$X1 -> TMP_CONTENTS_PLACE_MATCH
    substr(TMP_CONTENTS_PLACE_MATCH[[1]],1,1) -> TMP_CONTENTS_PLACE_MATCH
    
    #OPPNENT
    gsub(GSUB_H,"",get(TMP_HTML_TABLE_NAME)[[k]]$X1) -> TMP_CONTENTS_NAME_MATCH
    gsub(GSUB_A,"",TMP_CONTENTS_NAME_MATCH) -> TMP_CONTENTS_NAME_MATCH
    TMP_CONTENTS_NAME_MATCH[[1]] -> TMP_CONTENTS_NAME_MATCH
    
    #RESULT
    get(TMP_HTML_TABLE_NAME)[[k]]$X1 -> TMP_CONTENTS_RESULT_MATCH
    TMP_CONTENTS_RESULT_MATCH[[2]] -> TMP_CONTENTS_RESULT_MATCH
    substr(TMP_CONTENTS_RESULT_MATCH,result_charac_pos,result_charac_pos) -> TMP_CONTENTS_RESULT_MATCH
    
    #HOME TEAM SCORE
    gsub(GSUB_A,"",get(TMP_HTML_TABLE_NAME)[[k]]$X1) -> TMP_CONTENTS_mScore_MATCH
    TMP_CONTENTS_mScore_MATCH[[2]] -> TMP_CONTENTS_mScore_MATCH
    substr(TMP_CONTENTS_mScore_MATCH,mScore_charac_pos,mScore_charac_pos) -> TMP_CONTENTS_mScore_MATCH
    
    #AWAY TEAM SCORE
    gsub(GSUB_A,"",get(TMP_HTML_TABLE_NAME)[[k]]$X1) -> TMP_CONTENTS_oScore_MATCH
    TMP_CONTENTS_oScore_MATCH[[2]] -> TMP_CONTENTS_oScore_MATCH
    substr(TMP_CONTENTS_oScore_MATCH,oScore_charac_pos,oScore_charac_pos) -> TMP_CONTENTS_oScore_MATCH
    
    #�ߔԍ�
    sufURL[[j]] -> TMP_NUM_SEG_times
    TMP_NUM_SEG_times + k -> seg_num
    
    #�}�g���N�X�`����Export
    #TMP_EXPORT_FILE_NEW <- data.frame(home=team[team_count], number=prefix_tmp+l, name=TMP_CONTENTS_NAME_MATCH, home_away=TMP_CONTENTS_PLACE_MATCH, result=TMP_CONTENTS_RESULT_MATCH, mScore=TMP_CONTENTS_mScore_MATCH, oScore=TMP_CONTENTS_oScore_MATCH)
    TMP_EXPORT_FILE_NEW <- data.frame(home=TMP_CONTENTS_HOME_NAME, number=k, segNum=seg_num, name=TMP_CONTENTS_NAME_MATCH, home_away=TMP_CONTENTS_PLACE_MATCH, result=TMP_CONTENTS_RESULT_MATCH, mScore=TMP_CONTENTS_mScore_MATCH, oScore=TMP_CONTENTS_oScore_MATCH)
    print(TMP_EXPORT_FILE_NEW)
    TMP_EXPORT_FILE <- rbind(TMP_EXPORT_FILE,TMP_EXPORT_FILE_NEW)
    TMP_EXPORT_FILE_NEW <- TMP_EXPORT_FILE_NEW[-1,]

  }  
    
  seg_start = seg_start + 9
  seg_end = seg_end + 9

}

#Export to csv
#write.csv(TMP_EXPORT_FILE, "C:\\Users\\noriaki.sasaki\\toto_201806111821.csv", quote=F, col.names=F, append=T)
write.csv(TMP_EXPORT_FILE, CSV_EXPORT_FILE, quote=F, col.names=F, append=T)
