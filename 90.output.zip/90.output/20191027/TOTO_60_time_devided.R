TMP_TIME_DEVIDED_ORIGIN <- paste(Category,"_TIME_DEVIDED_",sep="")
recall_html <- read_html("https://data.j-league.or.jp/SFTD06/search?selectFlag=3&competitionFrameId=1&startYear=2019&endYear=&point=1")
#assign(TMP_TIME_DEVIDED_ORIGIN,read_html("https://data.j-league.or.jp/SFTD06/search?selectFlag=3&competitionFrameId=1&startYear=2019&endYear=&point=1"))

###�ǂݍ���HTML����"class=".child""�̍��ڂ̂ݒ��o���A�i�[
#paste("Tmp_Get_time_devided_Table_J1",sep="") -> TMP_GET_TIME_DEVIDED_TABLE_NAME
#assign(paste(TMP_GET_TIME_DEVIDED_TABLE_NAME),html_nodes(TMP_TIME_DEVIDED_ORIGIN,param))
#html_nodes(TMP_TIME_DEVIDED_ORIGIN,"h1.title") -> title_node

###�ǂݍ���HTML�f�[�^(���o��)���e�[�u���`���Ŋi�[
#paste("Get_time_devided_Table_J1",sep="") -> GET_TIME_HTML_TABLE_NAME
#assign(paste(GET_TIME_HTML_TABLE_NAME),html_table(get(TMP_GET_TIME_DEVIDED_TABLE_NAME), fill=TRUE))



recall_html %>%
  html_nodes(".pd10-box") %>%
  html_text() -> matrix_time_devided  # �e�L�X�g�f�[�^�����o��


write.csv(matrix_time_devided,"C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_J1_time_devided_20190901192900.csv", quote=F, col.names=F, append=T)

###�t�@�C���ǂݍ���
read.csv("C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_J1_time_devided_20190901192900.csv", header=FALSE) -> TMP_IMPORT_TIME_DEVIDED

###���������̌�A��s�ڂ������Ȃ��Ă͂Ȃ�Ȃ�
#TMP_IMPORT_TIME_DEVIDED <- TMP_IMPORT_TIME_DEVIDED[-39,]

GSUB_DEVIDED_TIME="\t"
#gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED) -> TMP_IMPORT_TIME_DEVIDED_no_t


num_TIME_DEVIDED = length(TMP_IMPORT_TIME_DEVIDED)

TMP_TEAM_NAME <- c("dummy")
TMP_1st_1_15 <- c("dummy")
TMP_1st_16_30 <- c("dummy")
TMP_1st_31_end <- c("dummy")
TMP_2nd_1_15 <- c("dummy")
TMP_2nd_16_30 <- c("dummy")
TMP_2nd_31_end <- c("dummy")

#TEAM_NAME
i = 1
j = 22
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]
  
j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]
  
j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

#1st_1-15
i = 1
j = 24
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

#1st_16-30
i = 1
j = 25
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

#1st_31-end
i = 1
j = 26
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

#2nd_1-15
i = 1
j = 27
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

#2nd_16-30
i = 1
j = 28
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]


#2nd_31-end
i = 1
j = 29
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

#�x�N�g���փZ�b�g
cbind(TMP_TEAM_NAME, J1_team) -> TMP_NAME_J1_team
cbind(TMP_NAME_J1_team, TMP_1st_1_15) -> TMP_NAME_1st_15
cbind(TMP_NAME_1st_15, TMP_1st_16_30) -> TMP_NAME_1st_30
cbind(TMP_NAME_1st_30, TMP_1st_31_end) -> TMP_NAME_1st_end
cbind(TMP_NAME_1st_end, TMP_2nd_1_15) -> TMP_NAME_1st_2nd_15
cbind(TMP_NAME_1st_2nd_15, TMP_2nd_16_30) -> TMP_NAME_1st_2nd_30
cbind(TMP_NAME_1st_2nd_30, TMP_2nd_31_end) -> TMP_NAME_1st_2nd_end

write.csv(TMP_NAME_1st_2nd_end, "C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_J1_TIME_GOAL.csv", quote=F, col.names=F, append=T)
#write.csv(TMP_IMPORT_FILE_SORTED_COMBINED_Re_Num_five, CSV_EXPORT_FILE_five_match, quote=F, col.names=F, append=T)









TMP_TIME_DEVIDED_ORIGIN <- paste(Category,"_TIME_DEVIDED_",sep="")
recall_html <- read_html("https://data.j-league.or.jp/SFTD06/search?selectFlag=3&competitionFrameId=1&startYear=2019&endYear=2019&point=0")
#assign(TMP_TIME_DEVIDED_ORIGIN,read_html("https://data.j-league.or.jp/SFTD06/search?selectFlag=3&competitionFrameId=1&startYear=2019&endYear=&point=1"))

###�ǂݍ���HTML����"class=".child""�̍��ڂ̂ݒ��o���A�i�[
#paste("Tmp_Get_time_devided_Table_J1",sep="") -> TMP_GET_TIME_DEVIDED_TABLE_NAME
#assign(paste(TMP_GET_TIME_DEVIDED_TABLE_NAME),html_nodes(TMP_TIME_DEVIDED_ORIGIN,param))
#html_nodes(TMP_TIME_DEVIDED_ORIGIN,"h1.title") -> title_node

###�ǂݍ���HTML�f�[�^(���o��)���e�[�u���`���Ŋi�[
#paste("Get_time_devided_Table_J1",sep="") -> GET_TIME_HTML_TABLE_NAME
#assign(paste(GET_TIME_HTML_TABLE_NAME),html_table(get(TMP_GET_TIME_DEVIDED_TABLE_NAME), fill=TRUE))



recall_html %>%
  html_nodes(".pd10-box") %>%
  html_text() -> matrix_time_devided  # �e�L�X�g�f�[�^�����o��


write.csv(matrix_time_devided,"C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_J1_time_devided_lost_20190825192900.csv", quote=F, col.names=F, append=T)

###�t�@�C���ǂݍ���
read.csv("C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_J1_time_devided_lost_20190825192900.csv", header=FALSE) -> TMP_IMPORT_TIME_DEVIDED

###���������̌�A��s�ڂ������Ȃ��Ă͂Ȃ�Ȃ�
#TMP_IMPORT_TIME_DEVIDED <- TMP_IMPORT_TIME_DEVIDED[-39,]

GSUB_DEVIDED_TIME="\t"
#gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED) -> TMP_IMPORT_TIME_DEVIDED_no_t


num_TIME_DEVIDED = length(TMP_IMPORT_TIME_DEVIDED)

TMP_TEAM_NAME <- c("dummy")
TMP_1st_1_15 <- c("dummy")
TMP_1st_16_30 <- c("dummy")
TMP_1st_31_end <- c("dummy")
TMP_2nd_1_15 <- c("dummy")
TMP_2nd_16_30 <- c("dummy")
TMP_2nd_31_end <- c("dummy")

#TEAM_NAME
i = 1
j = 22
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_TEAM_NAME[i]

#1st_1-15
i = 1
j = 24
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_1_15[i]

#1st_16-30
i = 1
j = 25
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_16_30[i]

#1st_31-end
i = 1
j = 26
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_1st_31_end[i]

#2nd_1-15
i = 1
j = 27
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_1_15[i]

#2nd_16-30
i = 1
j = 28
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_16_30[i]


#2nd_31-end
i = 1
j = 29
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

j = j + 12
i = i + 1
as.character(gsub(GSUB_DEVIDED_TIME,"",TMP_IMPORT_TIME_DEVIDED[j,1])) -> TMP_2nd_31_end[i]

#�x�N�g���փZ�b�g
cbind(TMP_TEAM_NAME, J1_team) -> TMP_NAME_J1_team
cbind(TMP_NAME_J1_team, TMP_1st_1_15) -> TMP_NAME_1st_15
cbind(TMP_NAME_1st_15, TMP_1st_16_30) -> TMP_NAME_1st_30
cbind(TMP_NAME_1st_30, TMP_1st_31_end) -> TMP_NAME_1st_end
cbind(TMP_NAME_1st_end, TMP_2nd_1_15) -> TMP_NAME_1st_2nd_15
cbind(TMP_NAME_1st_2nd_15, TMP_2nd_16_30) -> TMP_NAME_1st_2nd_30
cbind(TMP_NAME_1st_2nd_30, TMP_2nd_31_end) -> TMP_NAME_1st_2nd_end

write.csv(TMP_NAME_1st_2nd_end, "C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_J1_TIME_LOST.csv", quote=F, col.names=F, append=T)
#write.csv(TMP_IMPORT_FILE_SORTED_COMBINED_Re_Num_five, CSV_EXPORT_FILE_five_match, quote=F, col.names=F, append=T)
