###�t�@�C���ǂݍ���
read.csv("C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_J1_test.csv", header=FALSE) -> TMP_IMPORT_FILE
###���������̌�A��s�ڂ������Ȃ��Ă͂Ȃ�Ȃ�
TMP_IMPORT_FILE <- TMP_IMPORT_FILE[-1,]

num_TMP_IMPORT_FILE <- nrow(TMP_IMPORT_FILE)
transaction_result <- matrix("",nrow=num_TMP_IMPORT_FILE,ncol=1)

#�������ʂ������_���֕ϊ�
for(r in 1:num_TMP_IMPORT_FILE){
  
  tmp_result_mark_cha <- TMP_IMPORT_FILE[r,7]
  tmp_result_mark <- as.character(tmp_result_mark_cha)
  
  if( is.na(tmp_result_mark)){
    transaction_result[r] <- "NA"
    transaction_result[r] <- 0
  }else{
    if( tmp_result_mark == win ){
    transaction_result[r] <- 3
    }else{
      if( tmp_result_mark == draw){
        transaction_result[r] <- 1
      }else{
        if( tmp_result_mark == lose){
          transaction_result[r] <- 0
        }
      }
    }
  }
}

cbind(TMP_IMPORT_FILE, transaction_result) -> TMP_IMPORT_FILE


#�������ݒ�p�̒l
###if(){
num_match=nrow(TMP_IMPORT_FILE)%/%num_match_J1
###}

#sort
TMP_IMPORT_FILE[order(TMP_IMPORT_FILE$V2),] -> TMP_IMPORT_FILE_SORTED
cbind(TMP_IMPORT_FILE_SORTED, c(1:nrow(TMP_IMPORT_FILE_SORTED))) -> TMP_IMPORT_FILE_SORTED_Num
cbind(TMP_IMPORT_FILE_SORTED_Num, c(1:nrow(TMP_IMPORT_FILE_SORTED_Num))%%num_match) -> TMP_IMPORT_FILE_SORTED_COMBINED_Re_Num


###write.csv(TMP_IMPORT_FILE_SORTED_COMBINED_Re_Num, "C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_J1_201812191735.csv", quote=F, col.names=F, append=T)
write.csv(TMP_IMPORT_FILE_SORTED_COMBINED_Re_Num, CSV_EXPORT_FILE, quote=F, col.names=F, append=T)

#��v�f��ǉ�
num <- nrow(TMP_IMPORT_FILE_SORTED)
#all_point  ���̎��_�ł̏����_���v
#all_point <- matrix(1:num, ncol=1)
all_point <- c(1:num)

#five_match_point  ���̎��_�ł̉ߋ��܎����̏����_���v
five_match_point <- c(1:num)

tmp_five_game_points <- 0

#for(i in 1:num){
for(i in 1:num){
  ###������54�܂ł��������񃊃Z�b�g���Ȃ��Ⴖ��Ȃ��H
  all_point[[i]] <- 0
  five_match_point[[i]] <- 0
  tmp_five_game_points[[1]] <- 0
  tmp_five_game_points[[2]] <- 0
  tmp_five_game_points[[3]] <- 0
  tmp_five_game_points[[4]] <- 0
  tmp_five_game_points[[5]] <- 0
  number_of_match <- TMP_IMPORT_FILE_SORTED_COMBINED_Re_Num[i,11]
  
  dev_number_of_match <- 5
    
  if(number_of_match == 1){
    dev_number_of_match = 1
  }

  if(number_of_match == 2){
    dev_number_of_match = 2
  }
  
  if(number_of_match == 3){
    dev_number_of_match = 3
  }
  
  if(number_of_match == 4){
    dev_number_of_match = 4
  }
  
  #�J�E���^
  j = 1
  
  #5�������̏����_���W�v
  for(j in 1:dev_number_of_match){
    k = i - dev_number_of_match + j

    if(k >= 1){
      tmp_result_point_before <- TMP_IMPORT_FILE_SORTED_COMBINED_Re_Num[k,10]
      tmp_result_point <- as.numeric(as.character(tmp_result_point_before))
    }else{
      tmp_result_mark_cha <- TMP_IMPORT_FILE_SORTED_COMBINED_Re_Num[k,7]
      tmp_result_mark <- as.character(tmp_result_mark_cha)
      
      tmp_result_point <- 0

      z <- 0
      
      #������񂭂邩�s���Ȃ̂�1�V�[�Y�����̃Q�[�����A1�Âk��ANA����Ȃ������瑦�Afor���𔲂���
      for(z in 1:num_match){
        if(is.na(tmp_result_mark)) {
          #print("continue go back until the cell is not non available")
          tmp_result_mark_cha <- TMP_IMPORT_FILE_SORTED_COMBINED_Re_Num[k-z,7]
          tmp_result_mark <- as.character(tmp_result_mark_cha)
        }else{
          tmp_result_point <- TMP_IMPORT_FILE_SORTED_COMBINED_Re_Num[k-z,10]
          print(tmp_result_point)
          break
        }
      }
    }
    tmp_five_game_points[[j]] = tmp_five_game_points[[j]] + tmp_result_point
  } 
  
  five_match_point[i] <- 0

  five_match_point_status_before <- TMP_IMPORT_FILE_SORTED_COMBINED_Re_Num[k,12]
  five_match_point_status <- as.numeric(as.character(five_match_point_status_before))
  
  if(five_match_point_status == 1){
    five_match_point[[i]] <- tmp_five_game_points[[dev_number_of_match]]
  }else{
    if(five_match_point_status <= 5){
      #pull_back <- i - five_match_point_status + 1
      #pull_back <- i + five_match_point_status
      #five_match_point[[i]] <- five_match_point[[i-1]] + tmp_five_game_points[[dev_number_of_match]] - five_match_point[[pull_back]]

      for(j in 1:dev_number_of_match){
        five_match_point[[i]] <- five_match_point[[i]] + tmp_five_game_points[[j]]
      }
      
    }else{
      #pull_back <- i-five_match_point_status
      #pull_back <- i + five_match_point_status
      #five_match_point[[i]] <- five_match_point[[i-1]] + tmp_five_game_points[[dev_number_of_match]] - five_match_point[[pull_back]]
      
      for(j in 1:5){
        five_match_point[[i]] <- five_match_point[[i]] + tmp_five_game_points[[j]]
      }
      
    }
  }
}

#�ŁAfive_point����o���オ�莟��A�x�N�g���փZ�b�g
cbind(TMP_IMPORT_FILE_SORTED_COMBINED_Re_Num, five_match_point) -> TMP_IMPORT_FILE_SORTED_COMBINED_Re_Num_five

###write.csv(TMP_IMPORT_FILE_SORTED_COMBINED_Re_Num, "C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_J1_201812191735.csv", quote=F, col.names=F, append=T)
write.csv(TMP_IMPORT_FILE_SORTED_COMBINED_Re_Num_five, CSV_EXPORT_FILE_five_match, quote=F, col.names=F, append=T)
