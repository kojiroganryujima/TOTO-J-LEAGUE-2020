#�����擾
format(Sys.time(), "%Y%m%d%H%M%S") -> DATE

#�ΏۃJ�e�S���[������
target_Category <- "J1"
#target_Category <- "J2"
#target_Category <- "J3"

##html�ǂݍ��ݎ��ɁAclass=".child"�̂ݒ��o���邽�߂̃p�����[�^�[
param=".child"

#�J�E���^
count=0
pre1=""
pre2=""
seg_start = 1
seg_end = 10

##�`�[�����p�����[�^�[(2019)
J1_team=c("SAPPORO","SENDAI","KASHIMA","URAWA","FC-TOKYO","KAWASAKI","F-YOKOHAMA","SHONAN","MATSUMOTO","SHIMIZU","IWATA","NAGOYA","GOSAKA","COSAKA","KOBE","HIROSHIMA","TOSU","OITA")
J2_team=c("YAMAGATA","MITO","TOCHIGI","OMIYA","CHIBA","KASHIWA","TOKYO-V","MACHIDA","YOKOHAMA-FC","KOFU","NIIGATA","KANAZAWA","GIFU","KYOTO","OKAYAMA","YAMAGUCHI","TOKUSHIMA","EHIME","FUKUOKA","NAGASAKI","KAGOSHIMA","RYUKYU")
J3_team=c("HACHINOHE","MORIOKA","AKITA","FUKUSHIMA","GUNMA","YSCC-YOKOHAMA","SAGAMIHARA","NAGANO","TOYAMA","FUJIEDA","NUMAZU","TOTTORI","SANUKI","KITAKYUSHU","KUMAMOTO","FC-TOKYO-U23","GOSAKA-U23","COSAKA-U23")

##�`�[�����J�E���g
num_match_J1=length(J1_team)
num_match_J2=length(J2_team)
num_match_J3=length(J3_team)

#Category=c("J1", "J2", "J3")
if(target_Category == "J1"){
  Category=c("J1")
  team = J1_team
  URL_BASE="https://data.j-league.or.jp/SFRT05/?competitionIdLabel=%E6%98%8E%E6%B2%BB%E5%AE%89%E7%94%B0%E7%94%9F%E5%91%BD%EF%BC%AA%EF%BC%91%E3%83%AA%E3%83%BC%E3%82%B0&yearIdLabel=2019%E5%B9%B4&yearId=2019&competitionId=460&search=search&currIdx="
}
if(target_Category == "J2"){
  Category=c("J2")
  team = J2_team
  URL_BASE="https://data.j-league.or.jp/SFRT05/?competitionIdLabel=%E6%98%8E%E6%B2%BB%E5%AE%89%E7%94%B0%E7%94%9F%E5%91%BD%EF%BC%AA%EF%BC%92%E3%83%AA%E3%83%BC%E3%82%B0&yearIdLabel=2019%E5%B9%B4&yearId=2019&competitionId=467&search=search&currIdx="
} 
if(target_Category == "J3"){
  Category=c("J3")
  team = J3_team
  URL_BASE="https://data.j-league.or.jp/SFRT05/?competitionIdLabel=%E6%98%8E%E6%B2%BB%E5%AE%89%E7%94%B0%E7%94%9F%E5%91%BD%EF%BC%AA%EF%BC%93%E3%83%AA%E3%83%BC%E3%82%B0&yearIdLabel=2019%E5%B9%B4&yearId=2019&competitionId=468&search=search&currIdx="
}

#URL�̃T�t�B�b�N�X�ϐ����Z�b�g
sufURL=c(-1, 9, 19, 29, 39, 49)

#URL�̃��X�g���Z�b�g
paste("URL_LIST","_",Category)
URL_LIST_Category <- list()

#�s�v������p�����[�^�[
GSUB_A="A\r\n\t\t\t\t\t\t"
GSUB_H="H\r\n\t\t\t\t\t\t"
GSUB_="\r\n\t\t\t\t"

##�ǂݍ���html��table���ڂ���K�v�ȕ����񒊏o���̕����ʒu�p�����[�^�[
result_charac_pos=1
mScore_charac_pos=8
oScore_charac_pos=12


#Export file
paste("MATCH_RECORD_",DATE,sep="") -> TMP_EXPORT_FILE
paste("MATCH_RECORD_",DATE,"_new",sep="") -> TMP_EXPORT_FILE_NEW

home <- c("dummy")
number <- c("dummy")
name <- c("dummy")
home_away <- c("dummy")
result <- c("dummy")
mScore <- c("dummy")
oScore <- c("dummy")
TMP_EXPORT_FILE <- data.frame(home=home, number=number, name=name, home_away=home_away, result=result, mScore=mScore, oScore=oScore)
TMP_EXPORT_FILE_NEW <- data.frame(home=home, number=number, name=name, home_away=home_away, result=result, mScore=mScore, oScore=oScore)
TMP_EXPORT_FILE <- TMP_EXPORT_FILE[-1,]
TMP_EXPORT_FILE_NEW <- TMP_EXPORT_FILE_NEW[-1,]

#CSV_EXPORT_FILE_BASE <- "C:\\Users\\noriaki.sasaki\\toto_"
CSV_EXPORT_FILE_BASE <- "C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_"
CSV=".csv"
CSV_EXPORT_FILE <- paste(CSV_EXPORT_FILE_BASE,Category,"_",DATE,CSV,sep="")

#�f�o�b�O�p�@�����擾���̂Q
format(Sys.time(), "%Y%m%d%H%M%S") -> DATE_2

CSV_EXPORT_FILE_five_match <- paste(CSV_EXPORT_FILE_BASE,"_",DATE,"_",DATE_2,"_",target_Category,CSV,sep="")




#��������(�L��)
win <- "��"
draw <- "��"
lose <- "��"
