#����@======================================================================
#�O����
##�p�b�P�[�W�ǂݍ���
install.packages("rvest", dep=TRUE)
library(rvest)
library(rpart)
library(stringr)
library(sys)

#Sys.sleep(10)

#�����擾
format(Sys.time(), "%Y%m%d%H%M%S") -> DATE

#���`�[�������
TMP_Gamba_ORIGIN <- paste("_Gamba_",sep="")

#�S�[�������i�[����x�N�g�����쐬
goal_num <- 30
TMP_HOME_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
TMP_AWAY_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
HOME_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
AWAY_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)

#�e������i�[����s����쐬
#�S�[���̋L�^
matrix_gamba <- matrix(0:0, nrow=50, ncol=10)
matrix_gamba_GOAL <- matrix(0:0, nrow=50, ncol=10)
matrix_gamba_LOST <- matrix(0:0, nrow=50, ncol=10)
matrix_gamba_GOAL_TIME <- matrix(0:0, nrow=50, ncol=6)
matrix_gamba_GOAL_TIME_NAME <- c("GOAL_0-15","GOAL_16-30","GOAL_31-45","GOAL_46-60","GOAL_61-75","GOAL_76-")
colnames(matrix_gamba_GOAL_TIME) <- matrix_gamba_GOAL_TIME_NAME
matrix_gamba_LOST_TIME <- matrix(0:0, nrow=50, ncol=6)
matrix_gamba_LOST_TIME_NAME <- c("LOST_0-15","LOST_16-30","LOST_31-45","LOST_46-60","LOST_61-75","LOST_76-")
colnames(matrix_gamba_LOST_TIME) <- matrix_gamba_LOST_TIME_NAME

#�ꎎ�����Ƃ̃S�[�����v
matrix_gamba_goal_sum <- matrix(0:0, nrow=50, ncol=2)
matrix_gamba_lost_sum <- matrix(0:0, nrow=50, ncol=2)

#��������
matrix_gamba_game_result <- matrix(0:0, nrow=50, ncol=1)
matrix_gamba_game_result_point <- matrix(0:0, nrow=50, ncol=1)

#5�������Ƃ̏����_���v
matrix_gamba_game_result_five_matches <- matrix(0:0, nrow=50, ncol=1)

#�S�[���W�v�p��
#�x�N�g���쐬
gamba_goal <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
gamba_lost <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)

#�}�g���N�X�쐬
matrix_gamba_GOAL <- rbind(matrix_gamba, gamba_goal)
matrix_gamba_LOST <- rbind(matrix_gamba, gamba_lost)

#�S�[���������Ԃ̋L�^�x�N�g�����쐬
gamba_goal_time <- matrix(0:0, nrow=50, ncol=6)
gamba_goal_time_name <- c("0-15","16-30","31-45","46-60","61-75","76-")
colnames(gamba_goal_time) <- gamba_goal_time_name
gamba_lost_time <- matrix(0:0, nrow=50, ncol=6)
gamba_lost_time_name <- c("0-15","16-30","31-45","46-60","61-75","76-")
colnames(gamba_lost_time) <- gamba_lost_time_name

#5�������Ƃ́A���ԑѕʓ��_�E���_�����}�g���N�X�쐬
matrix_gamba_goal_time_sum_five_matches <- matrix(0:0, nrow=50, ncol=6)
matrix_gamba_lost_time_sum_five_matches <- matrix(0:0, nrow=50, ncol=6)

#�e�������ƂɃI�t�B�V�����T�C�g��������擾
game_URL <- c(
  "https://www2.gamba-osaka.net/game/2019/517.html?_ga=2.98622360.787861729.1568788020-320299941.1568788020",#1
  "https://www2.gamba-osaka.net/game/2019/518.html?_ga=2.3118902.787861729.1568788020-320299941.1568788020",#2
  "https://www2.gamba-osaka.net/game/2019/522.html?_ga=2.172580835.1313542011.1569906614-320299941.1568788020",#3
  "https://www2.gamba-osaka.net/game/2019/524.html?_ga=2.172580835.1313542011.1569906614-320299941.1568788020",#4
  "https://www2.gamba-osaka.net/game/2019/525.html?_ga=2.172580835.1313542011.1569906614-320299941.1568788020",#5
  "https://www2.gamba-osaka.net/game/2019/526.html?_ga=2.246676036.1313542011.1569906614-320299941.1568788020",#6
  "https://www2.gamba-osaka.net/game/2019/528.html?_ga=2.246676036.1313542011.1569906614-320299941.1568788020",#7
  "https://www2.gamba-osaka.net/game/2019/529.html?_ga=2.246676036.1313542011.1569906614-320299941.1568788020",#8
  "https://www2.gamba-osaka.net/game/2019/531.html?_ga=2.246676036.1313542011.1569906614-320299941.1568788020",#9
  "https://www2.gamba-osaka.net/game/2019/532.html?_ga=2.250878662.1313542011.1569906614-320299941.1568788020",#10
  "https://www2.gamba-osaka.net/game/2019/534.html?_ga=2.250878662.1313542011.1569906614-320299941.1568788020",#11
  "https://www2.gamba-osaka.net/game/2019/535.html?_ga=2.250878662.1313542011.1569906614-320299941.1568788020",#12
  "https://www2.gamba-osaka.net/game/2019/537.html?_ga=2.78917844.1313542011.1569906614-320299941.1568788020",#13
  "https://www2.gamba-osaka.net/game/2019/538.html?_ga=2.78917844.1313542011.1569906614-320299941.1568788020",#14
  "https://www2.gamba-osaka.net/game/2019/539.html?_ga=2.78917844.1313542011.1569906614-320299941.1568788020",#15
  "https://www2.gamba-osaka.net/game/2019/540.html?_ga=2.78917844.1313542011.1569906614-320299941.1568788020",#16
  "https://www2.gamba-osaka.net/game/2019/541.html?_ga=2.185138793.1313542011.1569906614-320299941.1568788020",#17
  "https://www2.gamba-osaka.net/game/2019/543.html?_ga=2.185138793.1313542011.1569906614-320299941.1568788020",#18
  "https://www2.gamba-osaka.net/game/2019/544.html?_ga=2.185138793.1313542011.1569906614-320299941.1568788020",#19
  "https://www2.gamba-osaka.net/game/2019/545.html?_ga=2.185138793.1313542011.1569906614-320299941.1568788020",#20
  "https://www2.gamba-osaka.net/game/2019/546.html?_ga=2.185138793.1313542011.1569906614-320299941.1568788020",#21
  "https://www2.gamba-osaka.net/game/2019/547.html?_ga=2.183572454.1313542011.1569906614-320299941.1568788020",#22
  "https://www2.gamba-osaka.net/game/2019/548.html?_ga=2.183572454.1313542011.1569906614-320299941.1568788020",#23
  "https://www2.gamba-osaka.net/game/2019/549.html?_ga=2.183572454.1313542011.1569906614-320299941.1568788020",#24
  "https://www2.gamba-osaka.net/game/2019/550.html?_ga=2.183572454.1313542011.1569906614-320299941.1568788020",#25
  "https://www2.gamba-osaka.net/game/2019/551.html?_ga=2.183572454.1313542011.1569906614-320299941.1568788020",#26
  "https://www2.gamba-osaka.net/game/2019/552.html?_ga=2.142300786.1313542011.1569906614-320299941.1568788020"#27
#  "",#28
#  "",#29
#  "",#30
#  "",#31
#  "",#32
#  "",#33
#  "",#34
#  "",#35
#  "",#36
#  "",#37
#  "",#38
#  "",#39
#  "",#40
#  "",#41
#  "",#42
#  "",#43
#  "",#44
#  "",#45
#  "",#46
#  "",#47
#  "",#48
#  "",#49
#  ""#50
)


#�����J�n===============================================================================
#�Q�[�����
for(k in 1:length(game_URL)){
  
  TMP_HOME_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
  TMP_AWAY_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
  HOME_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
  AWAY_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
  
  #recall_html <- read_html("https://www2.gamba-osaka.net/game/2019/517.html?_ga=2.98622360.787861729.1568788020-320299941.1568788020")
  recall_html <- read_html(game_URL[k])
  
  #�S�[���ƃS�[�������v���[���[�����擾
  recall_html %>%
    html_nodes(".score_team_away") %>%
    html_text() -> home_away_gamba  # �e�L�X�g�f�[�^�����o��
  
  write.csv(home_away_gamba,"C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_gamba_.csv", quote=F, col.names=F, append=T)
  read.csv("C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_gamba_.csv", header=FALSE) -> TMP_GAMBA_home_away_updated
  
  
  #�z�[���Q�[���������̂��A�A�E�F�C�Q�[���������̂��m�F���邽�߂̏����擾
  if(TMP_GAMBA_home_away_updated[3,1] == "�K���o���"){
    game_kind <- "away"
  }else{
    game_kind <- "home"
  }
  
  #�z�[���`�[���̃S�[���C���v�b�g
  recall_html %>%
    html_nodes(".score_team_txt") %>%
    html_text() -> matrix_gamba_home_goal  # �e�L�X�g�f�[�^�����o��
  
  write.csv(matrix_gamba_home_goal[1],"C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_gamba_home_goal_score.csv", quote=F, col.names=F, append=T)
  read.csv("C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_gamba_home_goal_score.csv", header=FALSE) -> TMP_GAMBA_home_goal_updated
  
  #�A�E�F�C�`�[���̃S�[���C���v�b�g
  recall_html %>%
    html_nodes(".score_team_away") %>%
    html_text() -> matrix_gamba_away_goal  # �e�L�X�g�f�[�^�����o��
  
  write.csv(matrix_gamba_away_goal,"C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_gamba_away_goal_score.csv", quote=F, col.names=F, append=T)
  read.csv("C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_gamba_away_goal_score.csv", header=FALSE) -> TMP_GAMBA_away_goal_updated
    
  #�S�[�����ƃS�[�������v���[���[�̏����x�N�g���֊i�[
  for(i in 1:goal_num){
    
    #home�����J�E���^
    j <- (i*4) + 1
    
    #away�����J�E���^
    jj <- j - 1
    
    if(game_kind == "home"){
      #HOME
      tmp_na_check <- as.character(str_extract_all(TMP_GAMBA_home_goal_updated[j,1], "[0-9.]+"))
      if(is.na(tmp_na_check)){
      }else{
        TMP_HOME_GOAL[i] <- as.character(TMP_GAMBA_home_goal_updated[j,1])
        #first_place <- regexpr(" ", TMP_HOME_GOAL[i]) + 4
        first_place <- regexpr(tmp_na_check, TMP_HOME_GOAL[i]) + 2
        final_place <- first_place + 1
        
        #if(substr(TMP_HOME_GOAL[i], first_place, first_place) == "+"){
        tmp_plus_check <- regexpr("+", TMP_HOME_GOAL[i])
        if(tmp_plus_check > 2 ){
          first_place <- regexpr("+", TMP_HOME_GOAL[i]) - 3
          middle_place <- first_place + 1
          final_place <- regexpr("+", TMP_HOME_GOAL[i]) + 1
          tmp_first <- substr(TMP_HOME_GOAL[i], first_place, middle_place)
          tmp_second <- substr(TMP_HOME_GOAL[i], final_place, final_place)
          tmp_first <- as.integer(tmp_first)
          tmp_second <- as.integer(tmp_second)
          HOME_GOAL[i] <- tmp_first + tmp_second
        }else{
          first_place <- first_place - 2
          final_place <- first_place + 1
          HOME_GOAL[i] <- substr(TMP_HOME_GOAL[i], first_place, final_place)
        }
      }
      HOME_GOAL[i] <- as.integer(HOME_GOAL[i])
      
      #AWAY(Oppenent Goal)
#     if(is.na(TMP_GAMBA_away_goal_updated[jj,1])){
      tmp_na_check <- as.integer(str_extract_all(TMP_GAMBA_away_goal_updated[jj,1], "[0-9.]+"))
      if(is.na(tmp_na_check)){
      }else{
        TMP_AWAY_GOAL[i] <- as.character(TMP_GAMBA_away_goal_updated[jj,1])
        #first_place <- regexpr(" ", TMP_AWAY_GOAL[i]) + 4
        first_place <- regexpr(tmp_na_check, TMP_AWAY_GOAL[i]) + 2 
        final_place <- first_place + 1
        
        #if(substr(TMP_AWAY_GOAL[i], first_place, first_place) == "+"){
        tmp_plus_check <- regexpr("+", TMP_AWAY_GOAL[i])
        if(tmp_plus_check > 2 ){
          first_place <- regexpr("+", TMP_AWAY_GOAL[i]) - 3
          middle_place <- first_place + 1
          final_place <- regexpr("+", TMP_AWAY_GOAL[i]) + 1
          tmp_first <- substr(TMP_AWAY_GOAL[i], first_place, middle_place)
          tmp_second <- substr(TMP_AWAY_GOAL[i], final_place, final_place)
          tmp_first <- as.integer(tmp_first)
          tmp_second <- as.integer(tmp_second)
          AWAY_GOAL[i] <- tmp_first + tmp_second
        }else{
          first_place <- first_place - 2
          final_place <- first_place + 1
          AWAY_GOAL[i] <- substr(TMP_AWAY_GOAL[i], first_place, final_place)
        }
      }
      AWAY_GOAL[i] <- as.integer(AWAY_GOAL[i])
      
    }else{
      #AWAY
      tmp_na_check <- as.integer(str_extract_all(TMP_GAMBA_away_goal_updated[jj,1], "[0-9.]+"))
      if(is.na(tmp_na_check)){
      }else{
        TMP_AWAY_GOAL[i] <- as.character(TMP_GAMBA_away_goal_updated[jj,1])
        #first_place <- regexpr(" ", TMP_AWAY_GOAL[i]) + 4
        first_place <- regexpr(tmp_na_check, TMP_AWAY_GOAL[i]) + 2
        final_place <- first_place + 1
        
        #if(substr(TMP_AWAY_GOAL[i], first_place, first_place) == "+"){
        tmp_plus_check <- regexpr("+", TMP_AWAY_GOAL[i])
        if(tmp_plus_check > 2 ){
          first_place <- regexpr("+", TMP_AWAY_GOAL[i]) - 3
          middle_place <- first_place + 1
          final_place <- regexpr("+", TMP_AWAY_GOAL[i]) + 1
          tmp_first <- substr(TMP_AWAY_GOAL[i], first_place, middle_place)
          tmp_second <- substr(TMP_AWAY_GOAL[i], final_place, final_place)
          tmp_first <- as.integer(tmp_first)
          tmp_second <- as.integer(tmp_second)
          AWAY_GOAL[i] <- tmp_first + tmp_second
        }else{
          first_place <- first_place - 2
          final_place <- first_place + 1
          AWAY_GOAL[i] <- substr(TMP_AWAY_GOAL[i], first_place, final_place)
        }
      }
      AWAY_GOAL[i] <- as.integer(AWAY_GOAL[i])
      
      #HOME(Oppenent Goal)
      tmp_na_check <- as.integer(str_extract_all(TMP_GAMBA_home_goal_updated[j,1], "[0-9.]+"))
      if(is.na(tmp_na_check)){
      }else{
        TMP_HOME_GOAL[i] <- as.character(TMP_GAMBA_home_goal_updated[j,1])
        #first_place <- regexpr(" ", TMP_HOME_GOAL[i]) + 4
        first_place <- regexpr(tmp_na_check, TMP_HOME_GOAL[i]) + 2
        final_place <- first_place + 1
        
        #if(substr(TMP_HOME_GOAL[i], first_place, first_place) == "+"){
        tmp_plus_check <- regexpr("+", TMP_HOME_GOAL[i])
        if(tmp_plus_check > 2 ){
          first_place <- regexpr("+", TMP_HOME_GOAL[i]) - 3
          middle_place <- first_place + 1
          final_place <- regexpr("+", TMP_HOME_GOAL[i]) + 1
          tmp_first <- substr(TMP_HOME_GOAL[i], first_place, middle_place)
          tmp_second <- substr(TMP_HOME_GOAL[i], final_place, final_place)
          tmp_first <- as.integer(tmp_first)
          tmp_second <- as.integer(tmp_second)
          HOME_GOAL[i] <- tmp_first + tmp_second
        }else{
          first_place <- first_place - 2
          final_place <- first_place + 1
          HOME_GOAL[i] <- substr(TMP_HOME_GOAL[i], first_place, final_place)
        }
      }
      HOME_GOAL[i] <- as.integer(HOME_GOAL[i])
      
      HOME_GOAL <- as.integer(HOME_GOAL)
      AWAY_GOAL <- as.integer(AWAY_GOAL)
    }
  }
  #�e�S�[�������ԑѕʂɃ}�g���N�X�֊i�[
  if(game_kind == "home"){
    for(l in 1:10){
      #HOME GOAL COUNT
      if(is.na(HOME_GOAL[l])){
      }else{
        if((15 >= HOME_GOAL[l]) && (HOME_GOAL[l]>= 0)){
          gamba_goal_time[k,1] <- gamba_goal_time[k,1] +1
        }
        if((30 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 15)){
          gamba_goal_time[k,2] <- gamba_goal_time[k,2] +1
        }
        if((45 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 30)){
          gamba_goal_time[k,3] <- gamba_goal_time[k,3] +1
        }
        if((60 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 45)){
          gamba_goal_time[k,4] <- gamba_goal_time[k,4] +1
        }
        if((75 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 60)){
          gamba_goal_time[k,5] <- gamba_goal_time[k,5] +1
        }
        if(HOME_GOAL[l] > 76){
          gamba_goal_time[k,6] <- gamba_goal_time[k,6] +1
        }
      }
      
      #Opponent GOAL COUNT
      if(is.na(AWAY_GOAL[l])){
      }else{
        if((15 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] >= 0)){
          gamba_lost_time[k,1] <- gamba_lost_time[k,1] +1
        }
        if((30 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 15)){
          gamba_lost_time[k,2] <- gamba_lost_time[k,2] +1
        }
        if((45 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 30)){
          gamba_lost_time[k,3] <- gamba_lost_time[k,3] +1
        }
        if((60 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 45)){
          gamba_lost_time[k,4] <- gamba_lost_time[k,4] +1
        }
        if((75 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 60)){
          gamba_lost_time[k,5] <- gamba_lost_time[k,5] +1
        }
        if(AWAY_GOAL[l] >76){
          gamba_lost_time[k,6] <- gamba_lost_time[k,6] +1
        }
      }
    }
    
  }else{
    for(l in 1:10){
      #AWAY GOAL COUNT
      if(is.na(AWAY_GOAL[l])){
      }else{
        if( (15 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] >= 0)){
          gamba_goal_time[k,1] <- gamba_goal_time[k,1] +1
        }
        if(( 30 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 15)){
          gamba_goal_time[k,2] <- gamba_goal_time[k,2] +1
        }
        if(( 45 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 30)){
          gamba_goal_time[k,3] <- gamba_goal_time[k,3] +1
        }
        if(( 60 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 45)){
          gamba_goal_time[k,4] <- gamba_goal_time[k,4] +1
        }
        if(( 75 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 60)){
          gamba_goal_time[k,5] <- gamba_goal_time[k,5] +1
        }
        if(AWAY_GOAL[l] >76){
          gamba_goal_time[k,6] <- gamba_goal_time[k,6] +1
        }
      }
      
      #Opponent GOAL COUNT
      if(is.na(HOME_GOAL[l])){
      }else{
        if( (15 >= HOME_GOAL[l]) && (HOME_GOAL[l] >= 0)){
          gamba_lost_time[k,1] <- gamba_lost_time[k,1] +1
        }
        if(( 30 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 15)){
          gamba_lost_time[k,2] <- gamba_lost_time[k,2] +1
        }
        if(( 45 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 30)){
          gamba_lost_time[k,3] <- gamba_lost_time[k,3] +1
        }
        if(( 60 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 45)){
          gamba_lost_time[k,4] <- gamba_lost_time[k,4] +1
        }
        if(( 75 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 60)){
          gamba_lost_time[k,5] <- gamba_lost_time[k,5] +1
        }
        if(HOME_GOAL[l] >76){
          gamba_lost_time[k,6] <- gamba_lost_time[k,6] +1
        }
      }
    }
  }
}