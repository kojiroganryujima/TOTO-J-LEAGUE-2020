#����@======================================================================
#�O����
##�p�b�P�[�W�ǂݍ���
install.packages("rvest", dep=TRUE)
library(rvest)
library(rpart)
library(sys)

#Sys.sleep(10)

#�����擾
format(Sys.time(), "%Y%m%d%H%M%S") -> DATE

#���`�[�������
TMP_SAPPORO_ORIGIN <- paste("_sapporo_",sep="")

#�S�[�������i�[����x�N�g�����쐬
goal_num <- 10
TMP_HOME_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
TMP_AWAY_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
HOME_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
AWAY_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)

#�e������i�[����s����쐬
#�S�[���̋L�^
matrix_sapporo <- matrix(0:0, nrow=50, ncol=10)
matrix_sapporo_GOAL <- matrix(0:0, nrow=50, ncol=10)
matrix_sapporo_LOST <- matrix(0:0, nrow=50, ncol=10)
matrix_sapporo_GOAL_TIME <- matrix(0:0, nrow=50, ncol=6)
matrix_sapporo_GOAL_TIME_NAME <- c("GOAL_0-15","GOAL_16-30","GOAL_31-45","GOAL_46-60","GOAL_61-75","GOAL_76-")
colnames(matrix_sapporo_GOAL_TIME) <- matrix_sapporo_GOAL_TIME_NAME
matrix_sapporo_LOST_TIME <- matrix(0:0, nrow=50, ncol=6)
matrix_sapporo_LOST_TIME_NAME <- c("LOST_0-15","LOST_16-30","LOST_31-45","LOST_46-60","LOST_61-75","LOST_76-")
colnames(matrix_sapporo_LOST_TIME) <- matrix_sapporo_LOST_TIME_NAME

#�ꎎ�����Ƃ̃S�[�����v
matrix_sapporo_goal_sum <- matrix(0:0, nrow=50, ncol=2)
matrix_sapporo_lost_sum <- matrix(0:0, nrow=50, ncol=2)

#��������
matrix_sapporo_game_result <- matrix(0:0, nrow=50, ncol=1)
matrix_sapporo_game_result_point <- matrix(0:0, nrow=50, ncol=1)

#5�������Ƃ̎�������
matrix_sapporo_game_result_five_matches <- matrix(0:0, nrow=50, ncol=1)

#�S�[���W�v�p�̃x�N�g���쐬
#sapporo_goal <- c(HOME_GOAL[1],HOME_GOAL[2],HOME_GOAL[3],HOME_GOAL[4],HOME_GOAL[5],HOME_GOAL[6],HOME_GOAL[7],HOME_GOAL[8],HOME_GOAL[9],HOME_GOAL[10])
#sapporo_lost <- c(AWAY_GOAL[1],AWAY_GOAL[2],AWAY_GOAL[3],AWAY_GOAL[4],AWAY_GOAL[5],AWAY_GOAL[6],AWAY_GOAL[7],AWAY_GOAL[8],AWAY_GOAL[9],AWAY_GOAL[10])
sapporo_goal <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
sapporo_lost <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)

#�S�[���W�v�p�̃}�g���N�X�쐬
matrix_sapporo_GOAL <- rbind(matrix_sapporo, sapporo_goal)
matrix_sapporo_LOST <- rbind(matrix_sapporo, sapporo_lost)

#�S�[���������Ԃ̋L�^�x�N�g�����쐬
sapporo_goal_time <- matrix(0:0, nrow=50, ncol=6)
sapporo_goal_time_name <- c("0-15","16-30","31-45","46-60","61-75","76-")
colnames(sapporo_goal_time) <- sapporo_goal_time_name
sapporo_lost_time <- matrix(0:0, nrow=50, ncol=6)
sapporo_lost_time_name <- c("0-15","16-30","31-45","46-60","61-75","76-")
colnames(sapporo_lost_time) <- sapporo_lost_time_name

#5�������Ƃ́A���ԑѕʓ��_�E���_�����}�g���N�X
matrix_sapporo_goal_time_sum_five_matches <- matrix(0:0, nrow=50, ncol=6)
matrix_sapporo_lost_time_sum_five_matches <- matrix(0:0, nrow=50, ncol=6)

#�e�������ƂɃI�t�B�V�����T�C�g��������擾
game_URL <- c(
  "https://www.consadole-sapporo.jp/game/flash/?mid=47148" #1
)


#�����J�n===============================================================================
#�Q�[�����
for(k in 1:length(game_URL)){
  
  TMP_HOME_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
  TMP_AWAY_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
  HOME_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
  AWAY_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
  
  recall_html <- read_html("https://www.consadole-sapporo.jp/game/flash/?mid=47151")
  #recall_html <- read_html(game_URL[k])
  
  #�S�[���ƃS�[�������v���[���[�����擾
  recall_html %>%
    html_nodes(".row") %>%
    html_text() -> home_away_sapporo  # �e�L�X�g�f�[�^�����o��
  
  write.csv(home_away_sapporo,"C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_sapporo_.csv", quote=F, col.names=F, append=T)
  read.csv("C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_sapporo_.csv", header=FALSE) -> TMP_SAPPORO_home_away_updated
  
  
  #�z�[���Q�[���������̂��A�A�E�F�C�Q�[���������̂��m�F���邽�߂̏����擾
  home_away_check <- substr(TMP_SAPPORO_home_away_updated[9,1],13,14)
  if(home_away_check == "�D�y"){
    game_kind <- "home"
  }else{
    game_kind <- "away"
  }
  
  # recall_html %>%
  #   html_nodes(".scorer") %>%
  #   html_text() -> matrix_sapporo  # �e�L�X�g�f�[�^�����o��
  # 
  # write.csv(matrix_sapporo,"C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_sapporo.csv", quote=F, col.names=F, append=T)
  # read.csv("C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_sapporo.csv", header=FALSE) -> TMP_SAPPORO_updated
  
  TMP_SAPPORO_updated_home <- TMP_SAPPORO_home_away_updated[12,1]
  TMP_SAPPORO_updated_away <- TMP_SAPPORO_home_away_updated[14,1]
  regexpr("��",TMP_SAPPORO_updated_home)
  
  #�S�[�����ƃS�[�������v���[���[�̏����x�N�g���֊i�[
  for(i in 1:goal_num){
    
    j <- i +1
    
    if(game_kind == "home"){
      #HOME
      if(length(as.character(TMP_SAPPORO_updated[2,j]) > 0)){
        TMP_HOME_GOAL[i] <- as.character(TMP_SAPPORO_updated[2,j])
        final_place <- regexpr("'", TMP_HOME_GOAL[i])
        first_place <- final_place - 2
        
        if(substr(TMP_HOME_GOAL[i], first_place, first_place) == "+"){
          first_place <- final_place - 2
          middle_place <- first_place + 1
          tmp_first <- substr(TMP_HOME_GOAL[i], first_place, middle_place)
          tmp_second <- substr(TMP_HOME_GOAL[i], final_place, final_place)
          tmp_first <- as.integer(tmp_first)
          tmp_second <- as.integer(tmp_second)
          HOME_GOAL[i] <- tmp_first + tmp_second
        }else{
          final_place <- final_place - 1
          first_place_check <- substr(TMP_HOME_GOAL[i], first_place, first_place)
          if(is.na(first_place_check)){
          }else{
            if(first_place_check == "("){
              first_place <- first_place + 1
            }
          }
          HOME_GOAL[i] <- substr(TMP_HOME_GOAL[i], first_place, final_place)
        }
      }
      HOME_GOAL[i] <- as.integer(HOME_GOAL[i])
      
      #AWAY(Oppenent Goal)
      if(length(as.character(TMP_SAPPORO_updated[3,j]) > 0)){
        TMP_AWAY_GOAL[i] <- as.character(TMP_SAPPORO_updated[3,j])
        final_place <- regexpr("'", TMP_AWAY_GOAL[i])
        first_place <- final_place - 2
        
        if(substr(TMP_AWAY_GOAL[i], first_place, first_place) == "+"){
          first_place <- final_place - 2
          middle_place <- first_place + 1
          tmp_first <- substr(TMP_AWAY_GOAL[i], first_place, middle_place)
          tmp_second <- substr(TMP_AWAY_GOAL[i], final_place, final_place)
          tmp_first <- as.integer(tmp_first)
          tmp_second <- as.integer(tmp_second)
          AWAY_GOAL[i] <- tmp_first + tmp_second
        }else{
          final_place <- final_place - 1
          first_place_check <- substr(TMP_HOME_GOAL[i], first_place, first_place)
          if(is.na(first_place_check)){
          }else{
            if(first_place_check == "("){
              first_place <- first_place + 1
            }
          }
          AWAY_GOAL[i] <- substr(TMP_AWAY_GOAL[i], first_place, final_place)
        }
      }
      AWAY_GOAL[i] <- as.integer(AWAY_GOAL[i])
      
    }else{
      #AWAY
      if(length(as.character(TMP_SAPPORO_updated[3,j]) > 0)){
        TMP_AWAY_GOAL[i] <- as.character(TMP_SAPPORO_updated[3,j])
        final_place <- regexpr("'", TMP_AWAY_GOAL[i])
        first_place <- final_place - 2
        
        if(substr(TMP_AWAY_GOAL[i], first_place, first_place) == "+"){
          first_place <- final_place - 2
          middle_place <- first_place + 1
          tmp_first <- substr(TMP_AWAY_GOAL[i], first_place, middle_place)
          tmp_second <- substr(TMP_AWAY_GOAL[i], final_place, final_place)
          tmp_first <- as.integer(tmp_first)
          tmp_second <- as.integer(tmp_second)
          AWAY_GOAL[i] <- tmp_first + tmp_second
        }else{
          final_place <- final_place - 1
          first_place_check <- substr(TMP_HOME_GOAL[i], first_place, first_place)
          if(is.na(first_place_check)){
          }else{
            if(first_place_check == "("){
              first_place <- first_place + 1
            }
          }
          AWAY_GOAL[i] <- substr(TMP_AWAY_GOAL[i], first_place, final_place)
        }
      }
      AWAY_GOAL[i] <- as.integer(AWAY_GOAL[i])
      
      #HOME(Oppenent Goal)
      if(length(as.character(TMP_SAPPORO_updated[2,j]) > 0)){
        TMP_HOME_GOAL[i] <- as.character(TMP_SAPPORO_updated[2,j])
        final_place <- regexpr("'", TMP_HOME_GOAL[i])
        first_place <- final_place - 2
        
        if(substr(TMP_HOME_GOAL[i], first_place, first_place) == "+"){
          first_place <- first_place - 2
          middle_place <- first_place + 1
          final_place <- final_place - 1
          tmp_first <- substr(TMP_HOME_GOAL[i], first_place, middle_place)
          tmp_second <- substr(TMP_HOME_GOAL[i], final_place, final_place)
          tmp_first <- as.integer(tmp_first)
          tmp_second <- as.integer(tmp_second)
          HOME_GOAL[i] <- tmp_first + tmp_second
        }else{
          final_place <- final_place - 1
          first_place_check <- substr(TMP_HOME_GOAL[i], first_place, first_place)
          if(is.na(first_place_check)){
          }else{
            if(first_place_check == "("){
              first_place <- first_place + 1
            }
          }
          HOME_GOAL[i] <- substr(TMP_HOME_GOAL[i], first_place, final_place)
        }
      }
      HOME_GOAL[i] <- as.integer(HOME_GOAL[i])
      
      HOME_GOAL <- as.integer(HOME_GOAL)
      AWAY_GOAL <- as.integer(AWAY_GOAL)
    }
  }
  #�e�S�[�������ԑѕʂɃ}�g���N�X�֊i�[
  if(game_kind == "home"){
    for(l in 1:10){
      #HOME GOAL COUNT
      if(is.na(HOME_GOAL[l])){
      }else{
        if((15 >= HOME_GOAL[l]) && (HOME_GOAL[l]>= 0)){
          sapporo_goal_time[k,1] <- sapporo_goal_time[k,1] +1
        }
        if((30 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 15)){
          sapporo_goal_time[k,2] <- sapporo_goal_time[k,2] +1
        }
        if((45 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 30)){
          sapporo_goal_time[k,3] <- sapporo_goal_time[k,3] +1
        }
        if((60 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 45)){
          sapporo_goal_time[k,4] <- sapporo_goal_time[k,4] +1
        }
        if((75 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 60)){
          sapporo_goal_time[k,5] <- sapporo_goal_time[k,5] +1
        }
        if(HOME_GOAL[l] > 76){
          sapporo_goal_time[k,6] <- sapporo_goal_time[k,6] +1
        }
      }
      
      #Opponent GOAL COUNT
      if(is.na(AWAY_GOAL[l])){
      }else{
        if((15 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] >= 0)){
          sapporo_lost_time[k,1] <- sapporo_lost_time[k,1] +1
        }
        if((30 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 15)){
          sapporo_lost_time[k,2] <- sapporo_lost_time[k,2] +1
        }
        if((45 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 30)){
          sapporo_lost_time[k,3] <- sapporo_lost_time[k,3] +1
        }
        if((60 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 45)){
          sapporo_lost_time[k,4] <- sapporo_lost_time[k,4] +1
        }
        if((75 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 60)){
          sapporo_lost_time[k,5] <- sapporo_lost_time[k,5] +1
        }
        if(AWAY_GOAL[l] >76){
          sapporo_lost_time[k,6] <- sapporo_lost_time[k,6] +1
        }
      }
    }
    
  }else{
    for(l in 1:10){
      #AWAY GOAL COUNT
      if(is.na(AWAY_GOAL[l])){
      }else{
        if( (15 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] >= 0)){
          sapporo_goal_time[k,1] <- sapporo_goal_time[k,1] +1
        }
        if(( 30 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 15)){
          sapporo_goal_time[k,2] <- sapporo_goal_time[k,2] +1
        }
        if(( 45 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 30)){
          sapporo_goal_time[k,3] <- sapporo_goal_time[k,3] +1
        }
        if(( 60 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 45)){
          sapporo_goal_time[k,4] <- sapporo_goal_time[k,4] +1
        }
        if(( 75 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 60)){
          sapporo_goal_time[k,5] <- sapporo_goal_time[k,5] +1
        }
        if(AWAY_GOAL[l] >76){
          sapporo_goal_time[k,6] <- sapporo_goal_time[k,6] +1
        }
      }
      
      #Opponent GOAL COUNT
      if(is.na(HOME_GOAL[l])){
      }else{
        if( (15 >= HOME_GOAL[l]) && (HOME_GOAL[l] >= 0)){
          sapporo_lost_time[k,1] <- sapporo_lost_time[k,1] +1
        }
        if(( 30 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 15)){
          sapporo_lost_time[k,2] <- sapporo_lost_time[k,2] +1
        }
        if(( 45 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 30)){
          sapporo_lost_time[k,3] <- sapporo_lost_time[k,3] +1
        }
        if(( 60 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 45)){
          sapporo_lost_time[k,4] <- sapporo_lost_time[k,4] +1
        }
        if(( 75 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 60)){
          sapporo_lost_time[k,5] <- sapporo_lost_time[k,5] +1
        }
        if(HOME_GOAL[l] >76){
          sapporo_lost_time[k,6] <- sapporo_lost_time[k,6] +1
        }
      }
    }
  }
}