#����@======================================================================
#�O����
##�p�b�P�[�W�ǂݍ���
install.packages("rvest", dep=TRUE)
library(rvest)
library(rpart)
library(sys)

#Sys.sleep(10)

#�����擾
format(Sys.time(), "%Y%m%d%H%M%S") -> DATE

#���`�[�������
TMP_sanfrecce_ORIGIN <- paste("_sanfrecce_",sep="")

#�S�[�������i�[����x�N�g�����쐬
goal_num <- 10
TMP_HOME_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
TMP_AWAY_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
HOME_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
AWAY_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)

#�e������i�[����s����쐬
#�S�[���̋L�^
matrix_sanfrecce <- matrix(0:0, nrow=50, ncol=10)
matrix_sanfrecce_GOAL <- matrix(0:0, nrow=50, ncol=10)
matrix_sanfrecce_LOST <- matrix(0:0, nrow=50, ncol=10)
matrix_sanfrecce_GOAL_TIME <- matrix(0:0, nrow=50, ncol=6)
matrix_sanfrecce_GOAL_TIME_NAME <- c("GOAL_0-15","GOAL_16-30","GOAL_31-45","GOAL_46-60","GOAL_61-75","GOAL_76-")
colnames(matrix_sanfrecce_GOAL_TIME) <- matrix_sanfrecce_GOAL_TIME_NAME
matrix_sanfrecce_LOST_TIME <- matrix(0:0, nrow=50, ncol=6)
matrix_sanfrecce_LOST_TIME_NAME <- c("LOST_0-15","LOST_16-30","LOST_31-45","LOST_46-60","LOST_61-75","LOST_76-")
colnames(matrix_sanfrecce_LOST_TIME) <- matrix_sanfrecce_LOST_TIME_NAME

#�ꎎ�����Ƃ̃S�[�����v
matrix_sanfrecce_goal_sum <- matrix(0:0, nrow=50, ncol=2)
matrix_sanfrecce_lost_sum <- matrix(0:0, nrow=50, ncol=2)

#��������
matrix_sanfrecce_game_result <- matrix(0:0, nrow=50, ncol=1)
matrix_sanfrecce_game_result_point <- matrix(0:0, nrow=50, ncol=1)

#5�������Ƃ̎�������
matrix_sanfrecce_game_result_five_matches <- matrix(0:0, nrow=50, ncol=1)

#�S�[���W�v�p�̃x�N�g���쐬
#sanfrecce_goal <- c(HOME_GOAL[1],HOME_GOAL[2],HOME_GOAL[3],HOME_GOAL[4],HOME_GOAL[5],HOME_GOAL[6],HOME_GOAL[7],HOME_GOAL[8],HOME_GOAL[9],HOME_GOAL[10])
#sanfrecce_lost <- c(AWAY_GOAL[1],AWAY_GOAL[2],AWAY_GOAL[3],AWAY_GOAL[4],AWAY_GOAL[5],AWAY_GOAL[6],AWAY_GOAL[7],AWAY_GOAL[8],AWAY_GOAL[9],AWAY_GOAL[10])
sanfrecce_goal <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
sanfrecce_lost <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)

#�S�[���W�v�p�̃}�g���N�X�쐬
matrix_sanfrecce_GOAL <- rbind(matrix_sanfrecce, sanfrecce_goal)
matrix_sanfrecce_LOST <- rbind(matrix_sanfrecce, sanfrecce_lost)

#�S�[���������Ԃ̋L�^�x�N�g�����쐬
sanfrecce_goal_time <- matrix(0:0, nrow=50, ncol=6)
sanfrecce_goal_time_name <- c("0-15","16-30","31-45","46-60","61-75","76-")
colnames(sanfrecce_goal_time) <- sanfrecce_goal_time_name
sanfrecce_lost_time <- matrix(0:0, nrow=50, ncol=6)
sanfrecce_lost_time_name <- c("0-15","16-30","31-45","46-60","61-75","76-")
colnames(sanfrecce_lost_time) <- sanfrecce_lost_time_name

#5�������Ƃ́A���ԑѕʓ��_�E���_�����}�g���N�X
matrix_sanfrecce_goal_time_sum_five_matches <- matrix(0:0, nrow=50, ncol=6)
matrix_sanfrecce_lost_time_sum_five_matches <- matrix(0:0, nrow=50, ncol=6)

#�e�������ƂɃI�t�B�V�����T�C�g��������擾
game_URL <- c(
  "https://www.sanfrecce.co.jp/games/52604",#1
)
#  "",#35
#  "",#36
#  "",#37
#  "",#38
#  "",#39
#  "",#40
#  "",#41
#  "",#42
#  "",#43
#  "",#44
#  "",#45
#  "",#46
#  "",#47
#  "",#48
#  "",#49
#  ""#50
#  )



#�����J�n===============================================================================
#�Q�[�����
for(k in 1:length(game_URL)){
  
  TMP_HOME_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
  TMP_AWAY_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
  HOME_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
  AWAY_GOAL <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
  
  recall_html <- read_html("https://www.sanfrecce.co.jp/games/52604")
  recall_html <- read_html(game_URL[k])
  
  #�S�[���ƃS�[�������v���[���[�����擾
  recall_html %>%
    html_nodes(".gameReport-report__cardHome") %>%
    html_text() -> home_away_sanfrecce  # �e�L�X�g�f�[�^�����o��
  
  write.csv(home_away_sanfrecce,"C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_sanfrecce_.csv", quote=F, col.names=F, append=T)
  read.csv("C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_sanfrecce_.csv", header=FALSE) -> TMP_sanfrecce_home_away_updated
  
  
  #�z�[���Q�[���������̂��A�A�E�F�C�Q�[���������̂��m�F���邽�߂̏����擾
  home_away_check <- TMP_sanfrecce_home_away_updated[5,1]
  if(regexpr("�T���t���b�`�F�L��",home_away_check) > 1){
    game_kind <- "home"
  }else{
    game_kind <- "away"
  }
  
  recall_html %>%
    html_nodes(".gameReport-report__resultTable") %>%
    html_text() -> matrix_sanfrecce  # �e�L�X�g�f�[�^�����o��
  
  write.csv(matrix_sanfrecce,"C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_sanfrecce.csv", quote=F, col.names=F, append=T)
  read.csv("C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\output\\toto_sanfrecce.csv", header=FALSE) -> TMP_sanfrecce_updated
  
  #�S�[�����ƃS�[�������v���[���[�̏����x�N�g���֊i�[
  for(i in 1:goal_num){
    
    j <- i +1
    
    if(game_kind == "home"){
      #HOME
      if(length(as.character(TMP_sanfrecce_updated[2,j]) > 0)){
        TMP_HOME_GOAL[i] <- as.character(TMP_sanfrecce_updated[2,j])
        final_place <- regexpr("'", TMP_HOME_GOAL[i])
        first_place <- final_place - 2
        
        if(substr(TMP_HOME_GOAL[i], first_place, first_place) == "+"){
          first_place <- final_place - 2
          middle_place <- first_place + 1
          tmp_first <- substr(TMP_HOME_GOAL[i], first_place, middle_place)
          tmp_second <- substr(TMP_HOME_GOAL[i], final_place, final_place)
          tmp_first <- as.integer(tmp_first)
          tmp_second <- as.integer(tmp_second)
          HOME_GOAL[i] <- tmp_first + tmp_second
        }else{
          final_place <- final_place - 1
          first_place_check <- substr(TMP_HOME_GOAL[i], first_place, first_place)
          if(is.na(first_place_check)){
          }else{
            if(first_place_check == "("){
              first_place <- first_place + 1
            }
          }
          HOME_GOAL[i] <- substr(TMP_HOME_GOAL[i], first_place, final_place)
        }
      }
      HOME_GOAL[i] <- as.integer(HOME_GOAL[i])
      
      #AWAY(Oppenent Goal)
      if(length(as.character(TMP_sanfrecce_updated[3,j]) > 0)){
        TMP_AWAY_GOAL[i] <- as.character(TMP_sanfrecce_updated[3,j])
        final_place <- regexpr("'", TMP_AWAY_GOAL[i])
        first_place <- final_place - 2
        
        if(substr(TMP_AWAY_GOAL[i], first_place, first_place) == "+"){
          first_place <- final_place - 2
          middle_place <- first_place + 1
          tmp_first <- substr(TMP_AWAY_GOAL[i], first_place, middle_place)
          tmp_second <- substr(TMP_AWAY_GOAL[i], final_place, final_place)
          tmp_first <- as.integer(tmp_first)
          tmp_second <- as.integer(tmp_second)
          AWAY_GOAL[i] <- tmp_first + tmp_second
        }else{
          final_place <- final_place - 1
          first_place_check <- substr(TMP_HOME_GOAL[i], first_place, first_place)
          if(is.na(first_place_check)){
          }else{
            if(first_place_check == "("){
              first_place <- first_place + 1
            }
          }
          AWAY_GOAL[i] <- substr(TMP_AWAY_GOAL[i], first_place, final_place)
        }
      }
      AWAY_GOAL[i] <- as.integer(AWAY_GOAL[i])
      
    }else{
      #AWAY
      if(length(as.character(TMP_sanfrecce_updated[3,j]) > 0)){
        TMP_AWAY_GOAL[i] <- as.character(TMP_sanfrecce_updated[3,j])
        final_place <- regexpr("'", TMP_AWAY_GOAL[i])
        first_place <- final_place - 2
        
        if(substr(TMP_AWAY_GOAL[i], first_place, first_place) == "+"){
          first_place <- final_place - 2
          middle_place <- first_place + 1
          tmp_first <- substr(TMP_AWAY_GOAL[i], first_place, middle_place)
          tmp_second <- substr(TMP_AWAY_GOAL[i], final_place, final_place)
          tmp_first <- as.integer(tmp_first)
          tmp_second <- as.integer(tmp_second)
          AWAY_GOAL[i] <- tmp_first + tmp_second
        }else{
          final_place <- final_place - 1
          first_place_check <- substr(TMP_HOME_GOAL[i], first_place, first_place)
          if(is.na(first_place_check)){
          }else{
            if(first_place_check == "("){
              first_place <- first_place + 1
            }
          }
          AWAY_GOAL[i] <- substr(TMP_AWAY_GOAL[i], first_place, final_place)
        }
      }
      AWAY_GOAL[i] <- as.integer(AWAY_GOAL[i])
      
      #HOME(Oppenent Goal)
      if(length(as.character(TMP_sanfrecce_updated[2,j]) > 0)){
        TMP_HOME_GOAL[i] <- as.character(TMP_sanfrecce_updated[2,j])
        final_place <- regexpr("'", TMP_HOME_GOAL[i])
        first_place <- final_place - 2
        
        if(substr(TMP_HOME_GOAL[i], first_place, first_place) == "+"){
          first_place <- first_place - 2
          middle_place <- first_place + 1
          final_place <- final_place - 1
          tmp_first <- substr(TMP_HOME_GOAL[i], first_place, middle_place)
          tmp_second <- substr(TMP_HOME_GOAL[i], final_place, final_place)
          tmp_first <- as.integer(tmp_first)
          tmp_second <- as.integer(tmp_second)
          HOME_GOAL[i] <- tmp_first + tmp_second
        }else{
          final_place <- final_place - 1
          first_place_check <- substr(TMP_HOME_GOAL[i], first_place, first_place)
          if(is.na(first_place_check)){
          }else{
            if(first_place_check == "("){
              first_place <- first_place + 1
            }
          }
          HOME_GOAL[i] <- substr(TMP_HOME_GOAL[i], first_place, final_place)
        }
      }
      HOME_GOAL[i] <- as.integer(HOME_GOAL[i])
      
      HOME_GOAL <- as.integer(HOME_GOAL)
      AWAY_GOAL <- as.integer(AWAY_GOAL)
    }
  }
  #�e�S�[�������ԑѕʂɃ}�g���N�X�֊i�[
  if(game_kind == "home"){
    for(l in 1:10){
      #HOME GOAL COUNT
      if(is.na(HOME_GOAL[l])){
      }else{
        if((15 >= HOME_GOAL[l]) && (HOME_GOAL[l]>= 0)){
          sanfrecce_goal_time[k,1] <- sanfrecce_goal_time[k,1] +1
        }
        if((30 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 15)){
          sanfrecce_goal_time[k,2] <- sanfrecce_goal_time[k,2] +1
        }
        if((45 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 30)){
          sanfrecce_goal_time[k,3] <- sanfrecce_goal_time[k,3] +1
        }
        if((60 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 45)){
          sanfrecce_goal_time[k,4] <- sanfrecce_goal_time[k,4] +1
        }
        if((75 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 60)){
          sanfrecce_goal_time[k,5] <- sanfrecce_goal_time[k,5] +1
        }
        if(HOME_GOAL[l] > 76){
          sanfrecce_goal_time[k,6] <- sanfrecce_goal_time[k,6] +1
        }
      }
      
      #Opponent GOAL COUNT
      if(is.na(AWAY_GOAL[l])){
      }else{
        if((15 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] >= 0)){
          sanfrecce_lost_time[k,1] <- sanfrecce_lost_time[k,1] +1
        }
        if((30 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 15)){
          sanfrecce_lost_time[k,2] <- sanfrecce_lost_time[k,2] +1
        }
        if((45 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 30)){
          sanfrecce_lost_time[k,3] <- sanfrecce_lost_time[k,3] +1
        }
        if((60 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 45)){
          sanfrecce_lost_time[k,4] <- sanfrecce_lost_time[k,4] +1
        }
        if((75 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 60)){
          sanfrecce_lost_time[k,5] <- sanfrecce_lost_time[k,5] +1
        }
        if(AWAY_GOAL[l] >76){
          sanfrecce_lost_time[k,6] <- sanfrecce_lost_time[k,6] +1
        }
      }
    }
    
  }else{
    for(l in 1:10){
      #AWAY GOAL COUNT
      if(is.na(AWAY_GOAL[l])){
      }else{
        if( (15 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] >= 0)){
          sanfrecce_goal_time[k,1] <- sanfrecce_goal_time[k,1] +1
        }
        if(( 30 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 15)){
          sanfrecce_goal_time[k,2] <- sanfrecce_goal_time[k,2] +1
        }
        if(( 45 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 30)){
          sanfrecce_goal_time[k,3] <- sanfrecce_goal_time[k,3] +1
        }
        if(( 60 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 45)){
          sanfrecce_goal_time[k,4] <- sanfrecce_goal_time[k,4] +1
        }
        if(( 75 >= AWAY_GOAL[l]) && (AWAY_GOAL[l] > 60)){
          sanfrecce_goal_time[k,5] <- sanfrecce_goal_time[k,5] +1
        }
        if(AWAY_GOAL[l] >76){
          sanfrecce_goal_time[k,6] <- sanfrecce_goal_time[k,6] +1
        }
      }
      
      #Opponent GOAL COUNT
      if(is.na(HOME_GOAL[l])){
      }else{
        if( (15 >= HOME_GOAL[l]) && (HOME_GOAL[l] >= 0)){
          sanfrecce_lost_time[k,1] <- sanfrecce_lost_time[k,1] +1
        }
        if(( 30 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 15)){
          sanfrecce_lost_time[k,2] <- sanfrecce_lost_time[k,2] +1
        }
        if(( 45 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 30)){
          sanfrecce_lost_time[k,3] <- sanfrecce_lost_time[k,3] +1
        }
        if(( 60 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 45)){
          sanfrecce_lost_time[k,4] <- sanfrecce_lost_time[k,4] +1
        }
        if(( 75 >= HOME_GOAL[l]) && (HOME_GOAL[l] > 60)){
          sanfrecce_lost_time[k,5] <- sanfrecce_lost_time[k,5] +1
        }
        if(HOME_GOAL[l] >76){
          sanfrecce_lost_time[k,6] <- sanfrecce_lost_time[k,6] +1
        }
      }
    }
  }
}


#���L���X�g���āI�I
#�e�߂̃S�[�����v
matrix_sanfrecce_GOAL_SUM_NAME <- c("GOAL_SUM")
colnames(matrix_sanfrecce_goal_sum) <- matrix_sanfrecce_GOAL_SUM_NAME
for(m in 1:50){
  matrix_sanfrecce_goal_sum[m] <- sanfrecce_goal_time[m,1] + sanfrecce_goal_time[m,2] + sanfrecce_goal_time[m,3] + sanfrecce_goal_time[m,4] + sanfrecce_goal_time[m,5] + sanfrecce_goal_time[m,6]
  matrix_sanfrecce_lost_sum[m] <- sanfrecce_lost_time[m,1] + sanfrecce_lost_time[m,2] + sanfrecce_lost_time[m,3] + sanfrecce_lost_time[m,4] + sanfrecce_lost_time[m,5] + sanfrecce_lost_time[m,6]
}

#�e�߂̏����_�����}�g���N�X�֊i�[
matrix_sanfrecce_GAME_RESULT_NAME <- c("GAME_RESULT")
colnames(matrix_sanfrecce_game_result) <- matrix_sanfrecce_GAME_RESULT_NAME
matrix_sanfrecce_GAME_RESULT_POINT_NAME <- c("GAME_RESULT_POINT")
colnames(matrix_sanfrecce_game_result_point) <- matrix_sanfrecce_GAME_RESULT_POINT_NAME
for(n in 1:50){
  
  diff_point <- matrix_sanfrecce_goal_sum[n] - matrix_sanfrecce_lost_sum[n]
  
  if(diff_point > 0){
    matrix_sanfrecce_game_result[n] <- "�Z"
    matrix_sanfrecce_game_result_point[n] <- 3
  }
  if(diff_point < 0){
    matrix_sanfrecce_game_result[n] <- "�~"
    matrix_sanfrecce_game_result_point[n] <- 0
  }
  if(diff_point == 0){
    matrix_sanfrecce_game_result[n] <- "��"
    matrix_sanfrecce_game_result_point[n] <- 1
  }
}

#�e�߂̏����_�����}�g���N�X�֊i�[
matrix_sanfrecce_RESULT_FIVE_MATCHES_NAME <- c("RESULT_FIVE_MATCHES_NAME")
colnames(matrix_sanfrecce_game_result_five_matches) <- matrix_sanfrecce_RESULT_FIVE_MATCHES_NAME

for(o in 1:50){
  
  if(o == 1){
    matrix_sanfrecce_game_result_five_matches[o] <- matrix_sanfrecce_game_result_point[o]
  }
  if(o == 2){
    matrix_sanfrecce_game_result_five_matches[o] <- matrix_sanfrecce_game_result_point[1] + matrix_sanfrecce_game_result_point[o]
  }
  if(o == 3){
    matrix_sanfrecce_game_result_five_matches[o] <- matrix_sanfrecce_game_result_point[1] + matrix_sanfrecce_game_result_point[2] + matrix_sanfrecce_game_result_point[o]
  }
  if(o == 4){
    matrix_sanfrecce_game_result_five_matches[o] <- matrix_sanfrecce_game_result_point[1] + matrix_sanfrecce_game_result_point[2] + matrix_sanfrecce_game_result_point[3] + matrix_sanfrecce_game_result_point[o]
  }
  if(o >= 5){
    matrix_sanfrecce_game_result_five_matches[o] <- matrix_sanfrecce_game_result_point[o-1] + matrix_sanfrecce_game_result_point[o-2] + matrix_sanfrecce_game_result_point[o-3] + matrix_sanfrecce_game_result_point[o-4] + matrix_sanfrecce_game_result_point[o]
  }
}

#5�������Ƃ́A���ԑѕʓ��_�E���_�����}�g���N�X�֊i�[
#���_
matrix_sanfrecce_GOAL_FIVE_MATCHES_NAME <- c("S_F_M_GOAL_N_1-15","S_F_M_GOAL_N_16-30","S_F_M_GOAL_N_31-45","S_F_M_GOAL_N_45-60","S_F_M_GOAL_N_61-75","S_F_M_GOAL_N_76-90")
colnames(matrix_sanfrecce_goal_time_sum_five_matches) <- matrix_sanfrecce_GOAL_FIVE_MATCHES_NAME

for(p in 1:50){
  if(p == 1){
    matrix_sanfrecce_goal_time_sum_five_matches[p,1] <- sanfrecce_goal_time[p,1]
    matrix_sanfrecce_goal_time_sum_five_matches[p,2] <- sanfrecce_goal_time[p,2]
    matrix_sanfrecce_goal_time_sum_five_matches[p,3] <- sanfrecce_goal_time[p,3]
    matrix_sanfrecce_goal_time_sum_five_matches[p,4] <- sanfrecce_goal_time[p,4]
    matrix_sanfrecce_goal_time_sum_five_matches[p,5] <- sanfrecce_goal_time[p,5]
    matrix_sanfrecce_goal_time_sum_five_matches[p,6] <- sanfrecce_goal_time[p,6]
  }
  if(p == 2){
    matrix_sanfrecce_goal_time_sum_five_matches[p,1] <- sanfrecce_goal_time[p,1] + sanfrecce_goal_time[1,1]
    matrix_sanfrecce_goal_time_sum_five_matches[p,2] <- sanfrecce_goal_time[p,2] + sanfrecce_goal_time[1,2]
    matrix_sanfrecce_goal_time_sum_five_matches[p,3] <- sanfrecce_goal_time[p,3] + sanfrecce_goal_time[1,3]
    matrix_sanfrecce_goal_time_sum_five_matches[p,4] <- sanfrecce_goal_time[p,4] + sanfrecce_goal_time[1,4]
    matrix_sanfrecce_goal_time_sum_five_matches[p,5] <- sanfrecce_goal_time[p,5] + sanfrecce_goal_time[1,5]
    matrix_sanfrecce_goal_time_sum_five_matches[p,6] <- sanfrecce_goal_time[p,6] + sanfrecce_goal_time[1,6]
  }
  if(p == 3){
    matrix_sanfrecce_goal_time_sum_five_matches[p,1] <- sanfrecce_goal_time[p,1] + sanfrecce_goal_time[2,1] + sanfrecce_goal_time[1,1]
    matrix_sanfrecce_goal_time_sum_five_matches[p,2] <- sanfrecce_goal_time[p,2] + sanfrecce_goal_time[2,2] + sanfrecce_goal_time[1,2]
    matrix_sanfrecce_goal_time_sum_five_matches[p,3] <- sanfrecce_goal_time[p,3] + sanfrecce_goal_time[2,3] + sanfrecce_goal_time[1,3]
    matrix_sanfrecce_goal_time_sum_five_matches[p,4] <- sanfrecce_goal_time[p,4] + sanfrecce_goal_time[2,4] + sanfrecce_goal_time[1,4]
    matrix_sanfrecce_goal_time_sum_five_matches[p,5] <- sanfrecce_goal_time[p,5] + sanfrecce_goal_time[2,5] + sanfrecce_goal_time[1,5]
    matrix_sanfrecce_goal_time_sum_five_matches[p,6] <- sanfrecce_goal_time[p,6] + sanfrecce_goal_time[2,6] + sanfrecce_goal_time[1,6]
  }
  if(p == 4){
    matrix_sanfrecce_goal_time_sum_five_matches[p,1] <- sanfrecce_goal_time[p,1] + sanfrecce_goal_time[3,1] + sanfrecce_goal_time[2,1] + sanfrecce_goal_time[1,1]
    matrix_sanfrecce_goal_time_sum_five_matches[p,2] <- sanfrecce_goal_time[p,2] + sanfrecce_goal_time[3,2] + sanfrecce_goal_time[2,2] + sanfrecce_goal_time[1,2]
    matrix_sanfrecce_goal_time_sum_five_matches[p,3] <- sanfrecce_goal_time[p,3] + sanfrecce_goal_time[3,3] + sanfrecce_goal_time[2,3] + sanfrecce_goal_time[1,3]
    matrix_sanfrecce_goal_time_sum_five_matches[p,4] <- sanfrecce_goal_time[p,4] + sanfrecce_goal_time[3,4] + sanfrecce_goal_time[2,4] + sanfrecce_goal_time[1,4]
    matrix_sanfrecce_goal_time_sum_five_matches[p,5] <- sanfrecce_goal_time[p,5] + sanfrecce_goal_time[3,5] + sanfrecce_goal_time[2,5] + sanfrecce_goal_time[1,5]
    matrix_sanfrecce_goal_time_sum_five_matches[p,6] <- sanfrecce_goal_time[p,6] + sanfrecce_goal_time[3,6] + sanfrecce_goal_time[2,6] + sanfrecce_goal_time[1,6]
  }
  if(p >= 5){
    matrix_sanfrecce_goal_time_sum_five_matches[p,1] <- sanfrecce_goal_time[p,1] + sanfrecce_goal_time[4,1] + sanfrecce_goal_time[3,1] + sanfrecce_goal_time[2,1] + sanfrecce_goal_time[1,1]
    matrix_sanfrecce_goal_time_sum_five_matches[p,2] <- sanfrecce_goal_time[p,2] + sanfrecce_goal_time[4,2] + sanfrecce_goal_time[3,2] + sanfrecce_goal_time[2,2] + sanfrecce_goal_time[1,2]
    matrix_sanfrecce_goal_time_sum_five_matches[p,3] <- sanfrecce_goal_time[p,3] + sanfrecce_goal_time[4,3] + sanfrecce_goal_time[3,3] + sanfrecce_goal_time[2,3] + sanfrecce_goal_time[1,3]
    matrix_sanfrecce_goal_time_sum_five_matches[p,4] <- sanfrecce_goal_time[p,4] + sanfrecce_goal_time[4,4] + sanfrecce_goal_time[3,4] + sanfrecce_goal_time[2,4] + sanfrecce_goal_time[1,4]
    matrix_sanfrecce_goal_time_sum_five_matches[p,5] <- sanfrecce_goal_time[p,5] + sanfrecce_goal_time[4,5] + sanfrecce_goal_time[3,5] + sanfrecce_goal_time[2,5] + sanfrecce_goal_time[1,5]
    matrix_sanfrecce_goal_time_sum_five_matches[p,6] <- sanfrecce_goal_time[p,6] + sanfrecce_goal_time[4,6] + sanfrecce_goal_time[3,6] + sanfrecce_goal_time[2,6] + sanfrecce_goal_time[1,6]
  }
}

#���_
matrix_sanfrecce_LOST_FIVE_MATCHES_NAME <- c("S_F_M_LOST_N_1-15","S_F_M_LOST_N_16-30","S_F_M_LOST_N_31-45","S_F_M_LOST_N_45-60","S_F_M_LOST_N_61-75","S_F_M_LOST_N_76-90")
colnames(matrix_sanfrecce_lost_time_sum_five_matches) <- matrix_sanfrecce_LOST_FIVE_MATCHES_NAME

for(q in 1:50){
  if(q == 1){
    matrix_sanfrecce_lost_time_sum_five_matches[q,1] <- sanfrecce_lost_time[q,1]
    matrix_sanfrecce_lost_time_sum_five_matches[q,2] <- sanfrecce_lost_time[q,2]
    matrix_sanfrecce_lost_time_sum_five_matches[q,3] <- sanfrecce_lost_time[q,3]
    matrix_sanfrecce_lost_time_sum_five_matches[q,4] <- sanfrecce_lost_time[q,4]
    matrix_sanfrecce_lost_time_sum_five_matches[q,5] <- sanfrecce_lost_time[q,5]
    matrix_sanfrecce_lost_time_sum_five_matches[q,6] <- sanfrecce_lost_time[q,6]
  }
  if(q == 2){
    matrix_sanfrecce_lost_time_sum_five_matches[q,1] <- sanfrecce_lost_time[q,1] + sanfrecce_lost_time[1,1]
    matrix_sanfrecce_lost_time_sum_five_matches[q,2] <- sanfrecce_lost_time[q,2] + sanfrecce_lost_time[1,2]
    matrix_sanfrecce_lost_time_sum_five_matches[q,3] <- sanfrecce_lost_time[q,3] + sanfrecce_lost_time[1,3]
    matrix_sanfrecce_lost_time_sum_five_matches[q,4] <- sanfrecce_lost_time[q,4] + sanfrecce_lost_time[1,4]
    matrix_sanfrecce_lost_time_sum_five_matches[q,5] <- sanfrecce_lost_time[q,5] + sanfrecce_lost_time[1,5]
    matrix_sanfrecce_lost_time_sum_five_matches[q,6] <- sanfrecce_lost_time[q,6] + sanfrecce_lost_time[1,6]
  }
  if(q == 3){
    matrix_sanfrecce_lost_time_sum_five_matches[q,1] <- sanfrecce_lost_time[q,1] + sanfrecce_lost_time[2,1] + sanfrecce_lost_time[1,1]
    matrix_sanfrecce_lost_time_sum_five_matches[q,2] <- sanfrecce_lost_time[q,2] + sanfrecce_lost_time[2,2] + sanfrecce_lost_time[1,2]
    matrix_sanfrecce_lost_time_sum_five_matches[q,3] <- sanfrecce_lost_time[q,3] + sanfrecce_lost_time[2,3] + sanfrecce_lost_time[1,3]
    matrix_sanfrecce_lost_time_sum_five_matches[q,4] <- sanfrecce_lost_time[q,4] + sanfrecce_lost_time[2,4] + sanfrecce_lost_time[1,4]
    matrix_sanfrecce_lost_time_sum_five_matches[q,5] <- sanfrecce_lost_time[q,5] + sanfrecce_lost_time[2,5] + sanfrecce_lost_time[1,5]
    matrix_sanfrecce_lost_time_sum_five_matches[q,6] <- sanfrecce_lost_time[q,6] + sanfrecce_lost_time[2,6] + sanfrecce_lost_time[1,6]
  }
  if(q == 4){
    matrix_sanfrecce_lost_time_sum_five_matches[q,1] <- sanfrecce_lost_time[q,1] + sanfrecce_lost_time[3,1] + sanfrecce_lost_time[2,1] + sanfrecce_lost_time[1,1]
    matrix_sanfrecce_lost_time_sum_five_matches[q,2] <- sanfrecce_lost_time[q,2] + sanfrecce_lost_time[3,2] + sanfrecce_lost_time[2,2] + sanfrecce_lost_time[1,2]
    matrix_sanfrecce_lost_time_sum_five_matches[q,3] <- sanfrecce_lost_time[q,3] + sanfrecce_lost_time[3,3] + sanfrecce_lost_time[2,3] + sanfrecce_lost_time[1,3]
    matrix_sanfrecce_lost_time_sum_five_matches[q,4] <- sanfrecce_lost_time[q,4] + sanfrecce_lost_time[3,4] + sanfrecce_lost_time[2,4] + sanfrecce_lost_time[1,4]
    matrix_sanfrecce_lost_time_sum_five_matches[q,5] <- sanfrecce_lost_time[q,5] + sanfrecce_lost_time[3,5] + sanfrecce_lost_time[2,5] + sanfrecce_lost_time[1,5]
    matrix_sanfrecce_lost_time_sum_five_matches[q,6] <- sanfrecce_lost_time[q,6] + sanfrecce_lost_time[3,6] + sanfrecce_lost_time[2,6] + sanfrecce_lost_time[1,6]
  }
  if(q >= 5){
    matrix_sanfrecce_lost_time_sum_five_matches[q,1] <- sanfrecce_lost_time[q,1] + sanfrecce_lost_time[4,1] + sanfrecce_lost_time[3,1] + sanfrecce_lost_time[2,1] + sanfrecce_lost_time[1,1]
    matrix_sanfrecce_lost_time_sum_five_matches[q,2] <- sanfrecce_lost_time[q,2] + sanfrecce_lost_time[4,2] + sanfrecce_lost_time[3,2] + sanfrecce_lost_time[2,2] + sanfrecce_lost_time[1,2]
    matrix_sanfrecce_lost_time_sum_five_matches[q,3] <- sanfrecce_lost_time[q,3] + sanfrecce_lost_time[4,3] + sanfrecce_lost_time[3,3] + sanfrecce_lost_time[2,3] + sanfrecce_lost_time[1,3]
    matrix_sanfrecce_lost_time_sum_five_matches[q,4] <- sanfrecce_lost_time[q,4] + sanfrecce_lost_time[4,4] + sanfrecce_lost_time[3,4] + sanfrecce_lost_time[2,4] + sanfrecce_lost_time[1,4]
    matrix_sanfrecce_lost_time_sum_five_matches[q,5] <- sanfrecce_lost_time[q,5] + sanfrecce_lost_time[4,5] + sanfrecce_lost_time[3,5] + sanfrecce_lost_time[2,5] + sanfrecce_lost_time[1,5]
    matrix_sanfrecce_lost_time_sum_five_matches[q,6] <- sanfrecce_lost_time[q,6] + sanfrecce_lost_time[4,6] + sanfrecce_lost_time[3,6] + sanfrecce_lost_time[2,6] + sanfrecce_lost_time[1,6]
  }
}


#matrix_sanfrecce <- rbind(matrix_sanfrecce, HOME_GOAL[i])

matrix_sanfrecce_time <- cbind(matrix_sanfrecce_GOAL_TIME, matrix_sanfrecce_LOST_TIME)
matrix_sanfrecce_time_result <- cbind(matrix_sanfrecce_time,matrix_sanfrecce_game_result)
matrix_sanfrecce_all_time_result_five <- cbind(matrix_sanfrecce_time_result, matrix_sanfrecce_game_result_five_matches)
matrix_sanfrecce_all_time_result_five_goal <- cbind(matrix_sanfrecce_all_time_result_five, matrix_sanfrecce_goal_time_sum_five_matches)
matrix_sanfrecce_all_time_result_five_goal_lost <- cbind(matrix_sanfrecce_all_time_result_five_goal, matrix_sanfrecce_lost_time_sum_five_matches)

#read.csv("C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\20190903_csvcsv.csv", header=FALSE) -> TMP_20190903_updated

#����@����
#rpartmodel = rpart(BUY_INSURANCE ~ ., data = customers)
matrix_sanfrecce_all_time_result_five_frame <- as.data.frame(matrix_sanfrecce_all_time_result_five_goal_lost)
rpartmodel = rpart(GAME_RESULT ~ ., data = matrix_sanfrecce_all_time_result_five_frame)
rpartmodel_extracted <- matrix_sanfrecce_all_time_result_five_frame[1:27,]
rpartmodel = rpart(GAME_RESULT ~ ., data = rpartmodel_extracted)

#model = rpart(BUY_INSURANCE ~ ., data = customers[,-1:-7])
#model = rpart(BUY_INSURANCE ~ ., data = customers[,-1:-7], control = rpart.control(maxdepth = 4))
install.packages("rpart.plot")
library(rpart.plot)
rpart.plot(rpartmodel, extra = 4)