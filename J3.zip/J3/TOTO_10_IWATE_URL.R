#�`�[������񁚁���
TMP_TEAM_ORIGIN <- "�����"
TEAM_NAME_CONDITION <- "����ăO���[�W�����������"

game_URL <- c("https://www.football-lab.jp/iwte/report/?year=2020&month=03&date=08",#1
              "https://www.football-lab.jp/iwte/report/?year=2020&month=03&date=14",#2
              "https://www.football-lab.jp/iwte/report/?year=2020&month=03&date=22",#3
              "https://www.football-lab.jp/iwte/report/?year=2020&month=03&date=28",#4
              "https://www.football-lab.jp/iwte/report/?year=2020&month=04&date=05",#5
              "https://www.football-lab.jp/iwte/report/?year=2020&month=04&date=12",#6
              "https://www.football-lab.jp/iwte/report/?year=2020&month=04&date=26",#7
              "https://www.football-lab.jp/iwte/report/?year=2020&month=05&date=02",#8
              "https://www.football-lab.jp/iwte/report/?year=2020&month=05&date=06",#9
              "https://www.football-lab.jp/iwte/report/?year=2020&month=05&date=16",#10
              "https://www.football-lab.jp/iwte/report/?year=2020&month=05&date=31",#10
              "https://www.football-lab.jp/iwte/report/?year=2020&month=06&date=07",#13
              "https://www.football-lab.jp/iwte/report/?year=2020&month=06&date=14",#14
              "https://www.football-lab.jp/iwte/report/?year=2020&month=06&date=21",#14
              "https://www.football-lab.jp/iwte/report/?year=2020&month=06&date=27",#15
              "https://www.football-lab.jp/iwte/report/?year=2020&month=07&date=12",#17
              "https://www.football-lab.jp/iwte/report/?year=2020&month=07&date=18",#18
              "https://www.football-lab.jp/iwte/report/?year=2020&month=08&date=10",#19
              "https://www.football-lab.jp/iwte/report/?year=2020&month=08&date=16",#20
              "https://www.football-lab.jp/iwte/report/?year=2020&month=08&date=22",#21
              "https://www.football-lab.jp/iwte/report/?year=2020&month=08&date=29",#22
              "https://www.football-lab.jp/iwte/report/?year=2020&month=09&date=05",#23
              "https://www.football-lab.jp/iwte/report/?year=2020&month=09&date=12",#24
              "https://www.football-lab.jp/iwte/report/?year=2020&month=09&date=19",#24
              "https://www.football-lab.jp/iwte/report/?year=2020&month=09&date=22",#27
              "https://www.football-lab.jp/iwte/report/?year=2020&month=09&date=27",#27
              "https://www.football-lab.jp/iwte/report/?year=2020&month=10&date=03",#29
              "https://www.football-lab.jp/iwte/report/?year=2020&month=10&date=10",#29
              "https://www.football-lab.jp/iwte/report/?year=2020&month=10&date=17",#30
              "https://www.football-lab.jp/iwte/report/?year=2020&month=10&date=25",#31
              "https://www.football-lab.jp/iwte/report/?year=2020&month=11&date=14",#34
              "https://www.football-lab.jp/iwte/report/?year=2020&month=11&date=22",#35
              "https://www.football-lab.jp/iwte/report/?year=2020&month=11&date=29",#35
              "https://www.football-lab.jp/iwte/report/?year=2020&month=12&date=06",#37
              "https://www.football-lab.jp/iwte/report/?year=2020&month=12&date=13"#38
)