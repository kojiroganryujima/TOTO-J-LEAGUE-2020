#�`�[������񁚁���
TMP_TEAM_ORIGIN <- "�H�c"
TEAM_NAME_CONDITION <- "�u���E�u���b�c�H�c"

game_URL <- c("https://www.football-lab.jp/aki/report/?year=2020&month=03&date=08",#1
              "https://www.football-lab.jp/aki/report/?year=2020&month=03&date=22",#3
              "https://www.football-lab.jp/aki/report/?year=2020&month=03&date=28",#4
              "https://www.football-lab.jp/aki/report/?year=2020&month=04&date=04",#5
              "https://www.football-lab.jp/aki/report/?year=2020&month=04&date=11",#6
              "https://www.football-lab.jp/aki/report/?year=2020&month=04&date=26",#7
              "https://www.football-lab.jp/aki/report/?year=2020&month=05&date=02",#8
              "https://www.football-lab.jp/aki/report/?year=2020&month=05&date=06",#9
              "https://www.football-lab.jp/aki/report/?year=2020&month=05&date=16",#10
              "https://www.football-lab.jp/aki/report/?year=2020&month=05&date=31",#11
              "https://www.football-lab.jp/aki/report/?year=2020&month=06&date=06",#12
              "https://www.football-lab.jp/aki/report/?year=2020&month=06&date=14",#13
              "https://www.football-lab.jp/aki/report/?year=2020&month=06&date=21",#14
              "https://www.football-lab.jp/aki/report/?year=2020&month=06&date=28",#15
              "https://www.football-lab.jp/aki/report/?year=2020&month=07&date=05",#16
              "https://www.football-lab.jp/aki/report/?year=2020&month=07&date=12",#17
              "https://www.football-lab.jp/aki/report/?year=2020&month=07&date=18",#18
              "https://www.football-lab.jp/aki/report/?year=2020&month=08&date=10",#19
              "https://www.football-lab.jp/aki/report/?year=2020&month=08&date=16",#20
              "https://www.football-lab.jp/aki/report/?year=2020&month=08&date=22",#21
              "https://www.football-lab.jp/aki/report/?year=2020&month=08&date=30",#22
              "https://www.football-lab.jp/aki/report/?year=2020&month=09&date=04",#23
              "https://www.football-lab.jp/aki/report/?year=2020&month=09&date=12",#24
              "https://www.football-lab.jp/aki/report/?year=2020&month=09&date=19",#25
              "https://www.football-lab.jp/aki/report/?year=2020&month=09&date=22",#26
              "https://www.football-lab.jp/aki/report/?year=2020&month=09&date=27",#27
              "https://www.football-lab.jp/aki/report/?year=2020&month=10&date=10",#29
              "https://www.football-lab.jp/aki/report/?year=2020&month=10&date=25",#30
              "https://www.football-lab.jp/aki/report/?year=2020&month=10&date=26",#29
              "https://www.football-lab.jp/aki/report/?year=2020&month=11&date=14",#34
              "https://www.football-lab.jp/aki/report/?year=2020&month=11&date=28",#36
              "https://www.football-lab.jp/aki/report/?year=2020&month=12&date=13"#38
)