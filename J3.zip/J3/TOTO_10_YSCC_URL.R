#�`�[������񁚁���
TMP_TEAM_ORIGIN <- "YS���l"
TEAM_NAME_CONDITION <- "Y.S.C.C.���lYS���l"

game_URL <- c("https://www.football-lab.jp/toya/report/?year=2020&month=03&date=07",#1
              "https://www.football-lab.jp/toya/report/?year=2020&month=03&date=15",#2
              "https://www.football-lab.jp/toya/report/?year=2020&month=03&date=21",#3
              "https://www.football-lab.jp/toya/report/?year=2020&month=03&date=29",#3
              "https://www.football-lab.jp/toya/report/?year=2020&month=04&date=05",#6
              "https://www.football-lab.jp/toya/report/?year=2020&month=04&date=11",#6
              "https://www.football-lab.jp/toya/report/?year=2020&month=04&date=26",#6
              "https://www.football-lab.jp/toya/report/?year=2020&month=05&date=02",#8
              "https://www.football-lab.jp/toya/report/?year=2020&month=05&date=06",#8
              "https://www.football-lab.jp/toya/report/?year=2020&month=05&date=16",#10
              "https://www.football-lab.jp/toya/report/?year=2020&month=05&date=31",#10
              "https://www.football-lab.jp/toya/report/?year=2020&month=06&date=07",#14
              "https://www.football-lab.jp/toya/report/?year=2020&month=06&date=14",#14
              "https://www.football-lab.jp/toya/report/?year=2020&month=06&date=20",#14
              "https://www.football-lab.jp/toya/report/?year=2020&month=06&date=27",#15
              "https://www.football-lab.jp/toya/report/?year=2020&month=07&date=04",#17
              "https://www.football-lab.jp/toya/report/?year=2020&month=07&date=12",#17
              "https://www.football-lab.jp/toya/report/?year=2020&month=07&date=19",#17
              "https://www.football-lab.jp/toya/report/?year=2020&month=08&date=16",#20
              "https://www.football-lab.jp/toya/report/?year=2020&month=08&date=23",#20
              "https://www.football-lab.jp/toya/report/?year=2020&month=08&date=29",#22
              "https://www.football-lab.jp/toya/report/?year=2020&month=09&date=05",#24
              "https://www.football-lab.jp/toya/report/?year=2020&month=09&date=12",#24
              "https://www.football-lab.jp/toya/report/?year=2020&month=09&date=19",#24
              "https://www.football-lab.jp/toya/report/?year=2020&month=09&date=27",#27
              "https://www.football-lab.jp/toya/report/?year=2020&month=10&date=04",#30
              "https://www.football-lab.jp/toya/report/?year=2020&month=10&date=10",#30
              "https://www.football-lab.jp/toya/report/?year=2020&month=10&date=17",#30
              "https://www.football-lab.jp/toya/report/?year=2020&month=10&date=25",#30
              "https://www.football-lab.jp/toya/report/?year=2020&month=11&date=01",#30
              "https://www.football-lab.jp/toya/report/?year=2020&month=11&date=08",#34
              "https://www.football-lab.jp/toya/report/?year=2020&month=11&date=15",#34
              "https://www.football-lab.jp/toya/report/?year=2020&month=11&date=22",#34
              "https://www.football-lab.jp/toya/report/?year=2020&month=11&date=28",#35
              "https://www.football-lab.jp/toya/report/?year=2020&month=12&date=06",#35
              "https://www.football-lab.jp/toya/report/?year=2020&month=12&date=13"#38
)