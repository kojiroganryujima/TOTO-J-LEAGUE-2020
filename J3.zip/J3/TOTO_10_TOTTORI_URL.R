#�`�[������񁚁���
TMP_TEAM_ORIGIN <- "����"
TEAM_NAME_CONDITION <- "�K�C�i�[�����撹��"

game_URL <- c("https://www.football-lab.jp/sanu/report/?year=2020&month=03&date=08",#1
              "https://www.football-lab.jp/sanu/report/?year=2020&month=03&date=15",#2
              "https://www.football-lab.jp/sanu/report/?year=2020&month=03&date=21",#3
              "https://www.football-lab.jp/sanu/report/?year=2020&month=03&date=29",#5
              "https://www.football-lab.jp/sanu/report/?year=2020&month=04&date=05",#6
              "https://www.football-lab.jp/sanu/report/?year=2020&month=04&date=12",#6
              "https://www.football-lab.jp/sanu/report/?year=2020&month=05&date=02",#8
              "https://www.football-lab.jp/sanu/report/?year=2020&month=05&date=06",#8
              "https://www.football-lab.jp/sanu/report/?year=2020&month=05&date=17",#10
              "https://www.football-lab.jp/sanu/report/?year=2020&month=05&date=30",#10
              "https://www.football-lab.jp/sanu/report/?year=2020&month=06&date=06",#14
              "https://www.football-lab.jp/sanu/report/?year=2020&month=06&date=14",#14
              "https://www.football-lab.jp/sanu/report/?year=2020&month=06&date=21",#14
              "https://www.football-lab.jp/sanu/report/?year=2020&month=06&date=27",#15
              "https://www.football-lab.jp/sanu/report/?year=2020&month=07&date=04",#17
              "https://www.football-lab.jp/sanu/report/?year=2020&month=07&date=11",#17
              "https://www.football-lab.jp/sanu/report/?year=2020&month=07&date=19",#17
              "https://www.football-lab.jp/sanu/report/?year=2020&month=08&date=10",#19
              "https://www.football-lab.jp/sanu/report/?year=2020&month=08&date=16",#20
              "https://www.football-lab.jp/sanu/report/?year=2020&month=08&date=22",#20
              "https://www.football-lab.jp/sanu/report/?year=2020&month=08&date=29",#22
              "https://www.football-lab.jp/sanu/report/?year=2020&month=09&date=05",#24
              "https://www.football-lab.jp/sanu/report/?year=2020&month=09&date=13",#24
              "https://www.football-lab.jp/sanu/report/?year=2020&month=09&date=22",#24
              "https://www.football-lab.jp/sanu/report/?year=2020&month=09&date=27",#27
              "https://www.football-lab.jp/sanu/report/?year=2020&month=10&date=04",#30
              "https://www.football-lab.jp/sanu/report/?year=2020&month=10&date=11",#30
              "https://www.football-lab.jp/sanu/report/?year=2020&month=10&date=18",#30
              "https://www.football-lab.jp/sanu/report/?year=2020&month=10&date=25",#30
              "https://www.football-lab.jp/sanu/report/?year=2020&month=11&date=01",#30
              "https://www.football-lab.jp/sanu/report/?year=2020&month=11&date=07",#34
              "https://www.football-lab.jp/sanu/report/?year=2020&month=11&date=15",#34
              "https://www.football-lab.jp/sanu/report/?year=2020&month=11&date=29",#35
              "https://www.football-lab.jp/sanu/report/?year=2020&month=12&date=06",#35
              "https://www.football-lab.jp/sanu/report/?year=2020&month=12&date=13"#38
)