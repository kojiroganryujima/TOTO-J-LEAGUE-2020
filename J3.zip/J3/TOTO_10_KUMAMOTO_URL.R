#�`�[������񁚁���
TMP_TEAM_ORIGIN <- "�F�{"
TEAM_NAME_CONDITION <- "���A�b�\�F�{�F�{"

game_URL <- c("https://www.football-lab.jp/kuma/report/?year=2020&month=03&date=08",#1
              "https://www.football-lab.jp/kuma/report/?year=2020&month=03&date=14",#2
              "https://www.football-lab.jp/kuma/report/?year=2020&month=03&date=22",#3
              "https://www.football-lab.jp/kuma/report/?year=2020&month=03&date=28",#4
              "https://www.football-lab.jp/kuma/report/?year=2020&month=04&date=05",#5
              "https://www.football-lab.jp/kuma/report/?year=2020&month=04&date=12",#6
              "https://www.football-lab.jp/kuma/report/?year=2020&month=04&date=26",#7
              "https://www.football-lab.jp/kuma/report/?year=2020&month=05&date=02",#8
              "https://www.football-lab.jp/kuma/report/?year=2020&month=05&date=06",#8
              "https://www.football-lab.jp/kuma/report/?year=2020&month=05&date=16",#10
              "https://www.football-lab.jp/kuma/report/?year=2020&month=05&date=31",#10
              "https://www.football-lab.jp/kuma/report/?year=2020&month=06&date=14",#14
              "https://www.football-lab.jp/kuma/report/?year=2020&month=06&date=21",#14
              "https://www.football-lab.jp/kuma/report/?year=2020&month=06&date=28",#15
              "https://www.football-lab.jp/kuma/report/?year=2020&month=07&date=04",#17
              "https://www.football-lab.jp/kuma/report/?year=2020&month=07&date=12",#17
              "https://www.football-lab.jp/kuma/report/?year=2020&month=07&date=19",#18
              "https://www.football-lab.jp/kuma/report/?year=2020&month=08&date=10",#19
              "https://www.football-lab.jp/kuma/report/?year=2020&month=08&date=16",#20
              "https://www.football-lab.jp/kuma/report/?year=2020&month=08&date=22",#21
              "https://www.football-lab.jp/kuma/report/?year=2020&month=08&date=29",#22
              "https://www.football-lab.jp/kuma/report/?year=2020&month=09&date=06",#23
              "https://www.football-lab.jp/kuma/report/?year=2020&month=09&date=12",#24
              "https://www.football-lab.jp/kuma/report/?year=2020&month=09&date=19",#24
              "https://www.football-lab.jp/kuma/report/?year=2020&month=09&date=22",#27
              "https://www.football-lab.jp/kuma/report/?year=2020&month=09&date=27",#27
              "https://www.football-lab.jp/kuma/report/?year=2020&month=10&date=04",#30
              "https://www.football-lab.jp/kuma/report/?year=2020&month=10&date=10",#30
              "https://www.football-lab.jp/kuma/report/?year=2020&month=10&date=18",#30
              "https://www.football-lab.jp/kuma/report/?year=2020&month=11&date=01",#34
              "https://www.football-lab.jp/kuma/report/?year=2020&month=11&date=08",#34
              "https://www.football-lab.jp/kuma/report/?year=2020&month=11&date=14",#34
              "https://www.football-lab.jp/kuma/report/?year=2020&month=11&date=29",#35
              "https://www.football-lab.jp/kuma/report/?year=2020&month=12&date=06",#37
              "https://www.football-lab.jp/kuma/report/?year=2020&month=12&date=13"#38
)