#�`�[������񁚁���
TMP_TEAM_ORIGIN <- "C���23"
TEAM_NAME_CONDITION <- "C���23���"

game_URL <- c("https://www.football-lab.jp/c-23/report/?year=2020&month=03&date=07",#1
              "https://www.football-lab.jp/c-23/report/?year=2020&month=03&date=15",#2
              "https://www.football-lab.jp/c-23/report/?year=2020&month=03&date=21",#3
              "https://www.football-lab.jp/c-23/report/?year=2020&month=03&date=28",#4
              "https://www.football-lab.jp/c-23/report/?year=2020&month=04&date=05",#5
              "https://www.football-lab.jp/c-23/report/?year=2020&month=04&date=11",#6
              "https://www.football-lab.jp/c-23/report/?year=2020&month=04&date=26",#7
              "https://www.football-lab.jp/c-23/report/?year=2020&month=05&date=03",#8
              "https://www.football-lab.jp/c-23/report/?year=2020&month=05&date=06",#9
              "https://www.football-lab.jp/c-23/report/?year=2020&month=05&date=30",#11
              "https://www.football-lab.jp/c-23/report/?year=2020&month=06&date=07",#12
              "https://www.football-lab.jp/c-23/report/?year=2020&month=06&date=13",#13
              "https://www.football-lab.jp/c-23/report/?year=2020&month=06&date=20",#14
              "https://www.football-lab.jp/c-23/report/?year=2020&month=06&date=28",#15
              "https://www.football-lab.jp/c-23/report/?year=2020&month=07&date=04",#16
              "https://www.football-lab.jp/c-23/report/?year=2020&month=07&date=12",#17
              "https://www.football-lab.jp/c-23/report/?year=2020&month=07&date=19",#18
              "https://www.football-lab.jp/c-23/report/?year=2020&month=08&date=10",#19
              "https://www.football-lab.jp/c-23/report/?year=2020&month=08&date=15",#20
              "https://www.football-lab.jp/c-23/report/?year=2020&month=08&date=23",#21
              "https://www.football-lab.jp/c-23/report/?year=2020&month=08&date=30",#22
              "https://www.football-lab.jp/c-23/report/?year=2020&month=09&date=05",#23
              "https://www.football-lab.jp/c-23/report/?year=2020&month=09&date=13",#24
              "https://www.football-lab.jp/c-23/report/?year=2020&month=09&date=19",#25
              "https://www.football-lab.jp/c-23/report/?year=2020&month=09&date=22",#26
              "https://www.football-lab.jp/c-23/report/?year=2020&month=09&date=27",#27
              "https://www.football-lab.jp/c-23/report/?year=2020&month=10&date=04",#28
              "https://www.football-lab.jp/c-23/report/?year=2020&month=10&date=10",#29
              "https://www.football-lab.jp/c-23/report/?year=2020&month=10&date=18",#30
              "https://www.football-lab.jp/c-23/report/?year=2020&month=10&date=25",#31
              "https://www.football-lab.jp/c-23/report/?year=2020&month=11&date=01",#32
              "https://www.football-lab.jp/c-23/report/?year=2020&month=11&date=07",#33
              "https://www.football-lab.jp/c-23/report/?year=2020&month=11&date=15",#34
              "https://www.football-lab.jp/c-23/report/?year=2020&month=11&date=22",#35
              "https://www.football-lab.jp/c-23/report/?year=2020&month=11&date=29",#36
              "https://www.football-lab.jp/c-23/report/?year=2020&month=12&date=06"#37
)