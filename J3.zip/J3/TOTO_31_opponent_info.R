library(rvest)
#�����J�n===============================================================================
#�Q�[�����
own_team_path <- paste(goal_dif_fin,TEAM_NAME_CONDITION,".csv",sep="")
TMP_own_team_info <- read.csv(own_team_path, header=TRUE)

#���Y�߂̑ΐ푊���get
for(k in 1:section){
  opponent_team_path <- paste(goal_dif_fin,TMP_own_team_info[k,2],".csv",sep="")
  TMP_opponent_info <- read.csv(opponent_team_path, header=TRUE)
  
  o_team_goal_time[k,1] <- TMP_opponent_info[k,16]
  o_team_goal_time[k,2] <- TMP_opponent_info[k,17]
  o_team_goal_time[k,3] <- TMP_opponent_info[k,18]
  o_team_goal_time[k,4] <- TMP_opponent_info[k,19]
  o_team_goal_time[k,5] <- TMP_opponent_info[k,20]
  o_team_goal_time[k,6] <- TMP_opponent_info[k,21]
  o_team_goal_time[k,7] <- TMP_opponent_info[k,22]

  o_team_lost_time[k,1] <- TMP_opponent_info[k,23]
  o_team_lost_time[k,2] <- TMP_opponent_info[k,24]
  o_team_lost_time[k,3] <- TMP_opponent_info[k,25]
  o_team_lost_time[k,4] <- TMP_opponent_info[k,26]
  o_team_lost_time[k,5] <- TMP_opponent_info[k,27]
  o_team_lost_time[k,6] <- TMP_opponent_info[k,28]
  
  o_h_a_points[k,1] <- as.character(TMP_opponent_info[k,29])
  o_h_a_points[k,2] <- TMP_opponent_info[k,30]
}

matrix_own_oppo_info <- cbind(TMP_own_team_info,o_team_goal_time,o_team_lost_time,o_h_a_points)

csv_name <- paste(goal_dif_fin,"own_oppo_",TEAM_NAME_CONDITION,".csv",sep="")
write.csv(matrix_own_oppo_info,csv_name, quote=F, col.names=F, append=T)