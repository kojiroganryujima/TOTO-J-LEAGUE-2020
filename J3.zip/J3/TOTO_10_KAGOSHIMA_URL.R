#�`�[������񁚁���
TMP_TEAM_ORIGIN <- "������"
TEAM_NAME_CONDITION <- "���������i�C�e�b�hFC������"

game_URL <- c("https://www.football-lab.jp/iwte/report/?year=2020&month=03&date=08",#1
              "https://www.football-lab.jp/iwte/report/?year=2020&month=03&date=15",#2
              "https://www.football-lab.jp/iwte/report/?year=2020&month=03&date=21",#3
              "https://www.football-lab.jp/iwte/report/?year=2020&month=03&date=28",#4
              "https://www.football-lab.jp/iwte/report/?year=2020&month=04&date=05",#5
              "https://www.football-lab.jp/iwte/report/?year=2020&month=04&date=12",#6
              "https://www.football-lab.jp/iwte/report/?year=2020&month=04&date=26",#7
              "https://www.football-lab.jp/iwte/report/?year=2020&month=05&date=03",#8
              "https://www.football-lab.jp/iwte/report/?year=2020&month=05&date=17",#10
              "https://www.football-lab.jp/iwte/report/?year=2020&month=05&date=30",#10
              "https://www.football-lab.jp/iwte/report/?year=2020&month=06&date=06",#13
              "https://www.football-lab.jp/iwte/report/?year=2020&month=06&date=13",#14
              "https://www.football-lab.jp/iwte/report/?year=2020&month=06&date=20",#14
              "https://www.football-lab.jp/iwte/report/?year=2020&month=06&date=27",#15
              "https://www.football-lab.jp/iwte/report/?year=2020&month=07&date=05",#17
              "https://www.football-lab.jp/iwte/report/?year=2020&month=07&date=12",#17
              "https://www.football-lab.jp/iwte/report/?year=2020&month=07&date=18",#18
              "https://www.football-lab.jp/iwte/report/?year=2020&month=08&date=10",#19
              "https://www.football-lab.jp/iwte/report/?year=2020&month=08&date=15",#20
              "https://www.football-lab.jp/iwte/report/?year=2020&month=08&date=23",#21
              "https://www.football-lab.jp/iwte/report/?year=2020&month=08&date=30",#22
              "https://www.football-lab.jp/iwte/report/?year=2020&month=09&date=05",#23
              "https://www.football-lab.jp/iwte/report/?year=2020&month=09&date=12",#24
              "https://www.football-lab.jp/iwte/report/?year=2020&month=09&date=19",#24
              "https://www.football-lab.jp/iwte/report/?year=2020&month=09&date=22",#27
              "https://www.football-lab.jp/iwte/report/?year=2020&month=09&date=27",#27
              "https://www.football-lab.jp/iwte/report/?year=2020&month=10&date=18",#30
              "https://www.football-lab.jp/iwte/report/?year=2020&month=10&date=25",#31
              "https://www.football-lab.jp/iwte/report/?year=2020&month=11&date=01",#34
              "https://www.football-lab.jp/iwte/report/?year=2020&month=11&date=07",#34
              "https://www.football-lab.jp/iwte/report/?year=2020&month=11&date=15",#34
              "https://www.football-lab.jp/iwte/report/?year=2020&month=11&date=22",#35
              "https://www.football-lab.jp/iwte/report/?year=2020&month=11&date=28",#35
              "https://www.football-lab.jp/iwte/report/?year=2020&month=12&date=06",#37
              "https://www.football-lab.jp/iwte/report/?year=2020&month=12&date=13"#38
)