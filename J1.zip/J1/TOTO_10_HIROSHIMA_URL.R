#�`�[������񁚁���
TMP_TEAM_ORIGIN <- "�L��"
TEAM_NAME_CONDITION <- "�T���t���b�`�F�L���L��"

game_URL <- c("https://www.football-lab.jp/hiro/report/?year=2020&month=02&date=23",#1
              "https://www.football-lab.jp/hiro/report/?year=2020&month=03&date=01",#2
              "https://www.football-lab.jp/hiro/report/?year=2020&month=03&date=08",#3
              "https://www.football-lab.jp/hiro/report/?year=2020&month=03&date=14",#4
              "https://www.football-lab.jp/hiro/report/?year=2020&month=03&date=18",#5
              "https://www.football-lab.jp/hiro/report/?year=2020&month=03&date=22",#6
              "https://www.football-lab.jp/hiro/report/?year=2020&month=04&date=03",#7
              "https://www.football-lab.jp/hiro/report/?year=2020&month=04&date=12",#8
              "https://www.football-lab.jp/hiro/report/?year=2020&month=04&date=18",#9
              "https://www.football-lab.jp/hiro/report/?year=2020&month=04&date=25",#10
              "https://www.football-lab.jp/hiro/report/?year=2020&month=04&date=29",#11
              "https://www.football-lab.jp/hiro/report/?year=2020&month=05&date=03",#12
              "https://www.football-lab.jp/hiro/report/?year=2020&month=05&date=10",#13
              "https://www.football-lab.jp/hiro/report/?year=2020&month=05&date=16",#14
              "https://www.football-lab.jp/hiro/report/?year=2020&month=05&date=23",#15
              "https://www.football-lab.jp/hiro/report/?year=2020&month=05&date=31",#16
              "https://www.football-lab.jp/hiro/report/?year=2020&month=06&date=13",#17
              "https://www.football-lab.jp/hiro/report/?year=2020&month=06&date=21",#18
              "https://www.football-lab.jp/hiro/report/?year=2020&month=06&date=27",#19
              "https://www.football-lab.jp/hiro/report/?year=2020&month=07&date=01",#20
              "https://www.football-lab.jp/hiro/report/?year=2020&month=07&date=05",#21
              "https://www.football-lab.jp/hiro/report/?year=2020&month=08&date=15",#22
              "https://www.football-lab.jp/hiro/report/?year=2020&month=08&date=23",#23
              "https://www.football-lab.jp/hiro/report/?year=2020&month=08&date=29",#24
              "https://www.football-lab.jp/hiro/report/?year=2020&month=09&date=11",#25
              "https://www.football-lab.jp/hiro/report/?year=2020&month=09&date=18",#26
              "https://www.football-lab.jp/hiro/report/?year=2020&month=09&date=26",#27
              "https://www.football-lab.jp/hiro/report/?year=2020&month=10&date=03",#28
              "https://www.football-lab.jp/hiro/report/?year=2020&month=10&date=17",#29
              "https://www.football-lab.jp/hiro/report/?year=2020&month=10&date=31",#30
              "https://www.football-lab.jp/hiro/report/?year=2020&month=11&date=07",#31
              "https://www.football-lab.jp/hiro/report/?year=2020&month=11&date=21",#32
              "https://www.football-lab.jp/hiro/report/?year=2020&month=11&date=28",#33
              "https://www.football-lab.jp/hiro/report/?year=2020&month=12&date=05"#34
)