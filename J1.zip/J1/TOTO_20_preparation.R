##########Preriquesite
###Package install
# install.packages("rvest", dep=TRUE)
library(rvest)
library(sys)

#DATE & TIME
DATE_TIME <- format(Sys.time(), "%Y%m%d%H%M%S")

#Offset of goal/lose time
dif <- 0

#team name & goal/lose matrix
matrix_team <- matrix(0:0, nrow=50, ncol=10)
matrix_team_GOAL <- matrix(0:0, nrow=50, ncol=10)
matrix_team_LOST <- matrix(0:0, nrow=50, ncol=10)

#goal vector
team_goal <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
team_lost <- c(NA,NA,NA,NA,NA,NA,NA,NA,NA,NA)
#Bind Matrix and vector
matrix_team_GOAL <- rbind(matrix_team, team_goal)
matrix_team_LOST <- rbind(matrix_team, team_lost)
#Add goal/lose time
team_goal_time <- matrix(0:0, nrow=50, ncol=6)
team_goal_time_name <- c("GOAL_00_15","GOAL_16_30","GOAL_31_45","GOAL_46_60","GOAL_61_75","GOAL_76_")
# team_goal_time_name <- c("-15���܂ł̓��_","16��-30���܂ł̓��_","31��-45���܂ł̓��_","46��-60���܂ł̓��_","61��-75���܂ł̓��_","76���ȍ~�̓��_")
colnames(team_goal_time) <- team_goal_time_name
team_lost_time <- matrix(0:0, nrow=50, ncol=6)
# team_lost_time_name <- c("-15���܂ł̎��_","16��-30���܂ł̎��_","31��-45���܂ł̎��_","46��-60���܂ł̎��_","61��-75���܂ł̎��_","76���ȍ~�̎��_")
colnames(team_lost_time) <- team_lost_time_name

#temporary numbers of goals/loses per five matches matrix
matrix_team_goal_sum <- matrix(0:0, nrow=50, ncol=2)
matrix_team_lost_sum <- matrix(0:0, nrow=50, ncol=2)
#Points per five matches matrix
matrix_team_game_result_five_matches <- matrix(0:0, nrow=50, ncol=1)
#numbers of goals/loses per five matches matrix
matrix_team_goal_time_sum_five_matches <- matrix(0:0, nrow=50, ncol=6)
matrix_team_lost_time_sum_five_matches <- matrix(0:0, nrow=50, ncol=6)

#Opponent team infomation
opponent_team_name_list <- matrix(0:0, nrow=50, ncol=1)

#Add goal/lose player
matrix_team_GOAL_TIME <- matrix(0:0, nrow=50, ncol=6)
matrix_team_GOAL_TIME_NAME <- c("GOAL_00_15","GOAL_16_30","GOAL_31_45","GOAL_46_60","GOAL_61_75","GOAL_76_")
# matrix_team_GOAL_TIME_NAME <- c("-15���܂ł̓��_��","16��-30���܂ł̓��_��","31��-45���܂ł̓��_��","46��-60���܂ł̓��_��","61��-75���܂ł̓��_��","76���ȍ~�̓��_��")
colnames(matrix_team_GOAL_TIME) <- matrix_team_GOAL_TIME_NAME
matrix_team_LOST_TIME <- matrix(0:0, nrow=50, ncol=6)
matrix_team_LOST_TIME_NAME <- c("LOST_00_15","LOST_16_30","LOST_31_45","LOST_46_60","LOST_61_75","LOST_76_")
# matrix_team_LOST_TIME_NAME <- c("-15���܂ł̎��_��","16��-30���܂ł̎��_��","31��-45���܂ł̎��_��","46��-60���܂ł̎��_��","61��-75���܂ł̎��_��","76���ȍ~�̎��_��")
colnames(matrix_team_LOST_TIME) <- matrix_team_LOST_TIME_NAME

#Game result matrix
matrix_team_game_result <- matrix(0:0, nrow=50, ncol=1)
o_matrix_team_LOST_TIME_NAME <- c("match_result")
colnames(matrix_team_game_result) <- o_matrix_team_LOST_TIME_NAME

matrix_team_game_result_point <- matrix(0:0, nrow=50, ncol=1)
matrix_team_game_result_slide <- matrix(0:0, nrow=50, ncol=1)

#HOME&AWAY vector
vec_home_away <- matrix(0:0, nrow=50, ncol=1)
vec_home_away_name <- c("vec_home_away")
colnames(vec_home_away) <- vec_home_away_name

#Points vector
vec_point <- matrix(0:0, nrow=50, ncol=1)
vec_point_name <- c("vec_point")
colnames(vec_point) <- vec_point_name

#intermidiate output file
#file path
tmp_origin_info_file_path <- paste(path,"\\output\\toto_origin_team_.csv", sep="")
#file path prefix
goal_dif <- paste(path,"\\output\\matrix_all_", sep="")
goal_dif_fin <- paste(path,"\\output\\", sep="")
analytics_input_path <- paste(path,"\\output\\", sep="")

#Opponent team's matrix
o_team_goal_time <- matrix(0:0, nrow=50, ncol=7)
o_team_goal_time_name <- c("0g_five_match_points","o_GOAL_00_15","o_GOAL_16_30","o_GOAL_31_45","o_GOAL_46_60","o_GOAL_61_75","o_GOAL_76_")
colnames(o_team_goal_time) <- o_team_goal_time_name
o_team_lost_time <- matrix(0:0, nrow=50, ncol=6)
o_team_lost_time_name <- c("o_LOST_00_15","o_LOST_16_30","o_LOST_31_45","o_LOST_46_60","o_LOST_61_75","o_LOST_76_")
colnames(o_team_lost_time) <- o_team_lost_time_name

#Oponent team's points matrix
o_h_a_points <- matrix(0:0, nrow=50, ncol=2)
h_a_points_name <- c("o_home_away","o_points")
colnames(o_h_a_points) <- h_a_points_name