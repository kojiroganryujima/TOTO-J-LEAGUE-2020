##########Prerequisite
#####Install packages
install.packages("rvest", dep=TRUE)

###PATH
path = "C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\"
# path_category <- commandArgs(trailingOnly=TRUE)[1]
path_category <- "J1"
# path_category <- "J2"
# path_category <- "J3"
path <- paste(path,path_category,sep="")

###Numbers of games
# section <- commandArgs(trailingOnly=TRUE)[2]
section <- 1

###Execute flag of scraping
# scraping_flag <- commandArgs(trailingOnly=TRUE)[3]
scraping_flag <- 1

###Execute flag of combine the input of opponents team
# opponent_five_match_flag <- commandArgs(trailingOnly=TRUE)[4]
opponent_five_match_flag <- 1

###Execute Analytics Flag
# analytics_flag <- commandArgs(trailingOnly=TRUE)[5]
analytics_flag <- 0


if( path_category == "J1" ){
  ###Hokkaido Consadole Sapporo
  preparation_path <- paste(path,"\\","TOTO_10_SAPPORO_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)  
  }
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
  
  ###Vegalta Sendai
  preparation_path <- paste(path,"\\","TOTO_10_SENDAI_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)
  }
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
  
  ###Kashima Antlers
  #read preparation
  preparation_path <- paste(path,"\\","TOTO_10_KASHIMA_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)
  }
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
  
  ###Urawa Reds
  preparation_path <- paste(path,"\\","TOTO_10_URAWA_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)
  }
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
  
  ###Kashiwa Reysol
  preparation_path <- paste(path,"\\","TOTO_10_KASHIWA_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)
  }
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
  
  ###FC Tokyo
  preparation_path <- paste(path,"\\","TOTO_10_FCTOKYO_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)
  }
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
  
  ###Kawasaki Frontale
  preparation_path <- paste(path,"\\","TOTO_10_KAWASAKI_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)
  }
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
  
  ###Yokohama Marinos
  preparation_path <- paste(path,"\\","TOTO_10_FYOKOHAMA_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)
  }  
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
  
  ###YOKOHAMAFC
  preparation_path <- paste(path,"\\","TOTO_10_YOKOHAMAFC_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)
  }
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
  
  ###Shonan Bellmare
  preparation_path <- paste(path,"\\","TOTO_10_SHONAN_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)
  }
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
  
  ###Shimizu S-Pulse
  preparation_path <- paste(path,"\\","TOTO_10_SHIMIZU_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)
  }
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
  
  ###Nagoya Grampus
  preparation_path <- paste(path,"\\","TOTO_10_NAGOYA_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)
  }  
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
  
  ###Gamba Osaka
  preparation_path <- paste(path,"\\","TOTO_10_GOSAKA_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)
  }
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
  
  ###Cerezo Osaka
  preparation_path <- paste(path,"\\","TOTO_10_COSAKA_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)
  }
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
  
  ###VISSEL KOBE
  preparation_path <- paste(path,"\\","TOTO_10_KOBE_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)
  }
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
  
  ###Sanfrecce Hiroshima
  preparation_path <- paste(path,"\\","TOTO_10_HIROSHIMA_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)
  }
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
  
  ###Sagan Tosu
  preparation_path <- paste(path,"\\","TOTO_10_TOSU_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)
  }
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
  
  ###Oita Trinita
  preparation_path <- paste(path,"\\","TOTO_10_OITA_URL.R",sep="")
  source(preparation_path)
  #read packages
  game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
  source(game_URL_path)
  if( scraping_flag == 1){
    read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
    source(read_packages)
  }
  if(opponent_five_match_flag == 1){
    read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
    source(read_opponent)
  }
  if(analytics_flag == 1){
    read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
    source(read_analytics)
  }
}