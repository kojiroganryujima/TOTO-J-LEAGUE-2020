#�`�[������񁚁���
TMP_TEAM_ORIGIN <- "���lFM"
TEAM_NAME_CONDITION <- "���l�e�E�}���m�X���lFM"

game_URL <- c("https://www.football-lab.jp/y-fm/report/?year=2020&month=02&date=23",#1
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=02&date=29",#2
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=03&date=08",#3
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=03&date=14",#4
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=03&date=18",#5
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=03&date=22",#6
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=04&date=04",#7
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=04&date=12",#8
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=04&date=17",#9
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=04&date=25",#10
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=05&date=01",#12
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=05&date=10",#13
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=05&date=13",#11
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=05&date=17",#14
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=05&date=23",#15
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=05&date=31",#16
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=06&date=13",#17
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=06&date=21",#18
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=06&date=27",#19
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=07&date=01",#20
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=07&date=04",#21
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=08&date=14",#22
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=08&date=22",#23
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=08&date=29",#24
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=09&date=11",#25
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=09&date=18",#26
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=09&date=26",#27
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=10&date=03",#28
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=10&date=17",#29
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=10&date=31",#30
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=11&date=07",#31
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=11&date=21",#32
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=11&date=28",#33
              "https://www.football-lab.jp/y-fm/report/?year=2020&month=12&date=05"#34
)