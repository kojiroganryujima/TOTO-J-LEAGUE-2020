#�`�[������񁚁���
TMP_TEAM_ORIGIN <- "����V"
TEAM_NAME_CONDITION <- "�������F���f�B����V"

game_URL <- c("https://www.football-lab.jp/tk-v/report/?year=2020&month=02&date=23",#1
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=03&date=01",#2
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=03&date=07",#3
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=03&date=14",#4
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=03&date=18",#5
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=03&date=22",#6
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=03&date=29",#7
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=04&date=05",#8
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=04&date=11",#9
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=04&date=19",#10
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=04&date=26",#11
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=04&date=29",#12
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=05&date=03",#13
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=05&date=09",#14
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=05&date=13",#15
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=05&date=17",#16
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=05&date=24",#17
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=05&date=30",#18
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=06&date=06",#19
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=06&date=14",#20
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=06&date=20",#21
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=06&date=27",#22
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=07&date=04",#23
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=07&date=12",#24
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=07&date=18",#25
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=08&date=10",#26
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=08&date=15",#27
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=08&date=23",#28
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=08&date=30",#29
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=09&date=05",#30
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=09&date=13",#31
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=09&date=26",#32
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=09&date=30",#33
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=10&date=04",#35
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=10&date=10",#36
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=10&date=18",#37
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=10&date=25",#38
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=11&date=01",#39
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=11&date=08",#40
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=11&date=14",#41
              "https://www.football-lab.jp/tk-v/report/?year=2020&month=11&date=22"#42
)