##########Prerequisite
#####Install packages
install.packages("rvest", dep=TRUE)

###PATH
path = "C:\\Users\\noriaki.sasaki\\Documents\\TOTO\\"
# path_category <- commandArgs(trailingOnly=TRUE)[1]
# path_category <- "J1"
path_category <- "J2"
# path_category <- "J3"
path <- paste(path,path_category,sep="")

###Numbers of games
# section <- commandArgs(trailingOnly=TRUE)[2]
section <- 1

###Execute flag of scraping
# scraping_flag <- commandArgs(trailingOnly=TRUE)[3]
scraping_flag <- 1

###Execute flag of combine the input of opponents team
# opponent_five_match_flag <- commandArgs(trailingOnly=TRUE)[4]
opponent_five_match_flag <- 1

###Execute Analytics Flag
# analytics_flag <- commandArgs(trailingOnly=TRUE)[5]
analytics_flag <- 0


###Montedio Yamagata
preparation_path <- paste(path,"\\","TOTO_10_YAMAGATA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}


###Mito Holy Hook
preparation_path <- paste(path,"\\","TOTO_10_MITO_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}


###TOCHIGI SC
preparation_path <- paste(path,"\\","TOTO_10_TOCHIGI_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}


###The Spa Kusatsu Gunma
preparation_path <- paste(path,"\\","TOTO_10_GUNMA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###Omiya Ardija
preparation_path <- paste(path,"\\","TOTO_10_OMIYA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}


###Jef United Ichihara / Chiba
preparation_path <- paste(path,"\\","TOTO_10_CHIBA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)  
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###Tokyo Verdy
#read preparation
preparation_path <- paste(path,"\\","TOTO_10_VTOKYO_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###FC Machida Zelvia
preparation_path <- paste(path,"\\","TOTO_10_MACHIDA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###Ventforet Kofu
preparation_path <- paste(path,"\\","TOTO_10_KOFU_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}


##Matsumoto Yamaga FC
preparation_path <- paste(path,"\\","TOTO_10_MATSUMOTO_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}


###Albirex Niigata
preparation_path <- paste(path,"\\","TOTO_10_NIIGATA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}


###Zuegen Kanazawa
preparation_path <- paste(path,"\\","TOTO_10_KANAZAWA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}


###Jubilo Iwata
preparation_path <- paste(path,"\\","TOTO_10_IWATA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}


###Kyoto Sanga F.C.
preparation_path <- paste(path,"\\","TOTO_10_KYOTO_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}  
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###Fagiano Okayama
preparation_path <- paste(path,"\\","TOTO_10_OKAYAMA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}


###Renofa Yamaguchi FC
preparation_path <- paste(path,"\\","TOTO_10_YAMAGUCHI_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}


###Tokushima Voltis
preparation_path <- paste(path,"\\","TOTO_10_TOKUSHIMA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###Ehime FC
preparation_path <- paste(path,"\\","TOTO_10_EHIME_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}  
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}


###Avispa Fukuoka
preparation_path <- paste(path,"\\","TOTO_10_FUKUOKA_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###Giravanz Kitakyushu
preparation_path <- paste(path,"\\","TOTO_10_KITAKYUSHU_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###V. Farren Nagasaki
preparation_path <- paste(path,"\\","TOTO_10_NAGASAKI_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}

###FC Ryukyu
preparation_path <- paste(path,"\\","TOTO_10_RYUKYU_URL.R",sep="")
source(preparation_path)
#read packages
game_URL_path <- paste(path,"\\","TOTO_20_preparation.R",sep="")
source(game_URL_path)
if( scraping_flag == 1){
  read_packages <- paste(path,"\\","TOTO_30_scraping.R",sep="")
  source(read_packages)
}
if(opponent_five_match_flag == 1){
  read_opponent <- paste(path,"\\","TOTO_31_opponent_info.R",sep="")
  source(read_opponent)
}
if(analytics_flag == 1){
  read_analytics <- paste(path,"\\","TOTO_40_analytics.R",sep="")
  source(read_analytics)
}