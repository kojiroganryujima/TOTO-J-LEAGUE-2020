#�Ώۃ`�[�����̓ǂݍ���
input_path <- paste(goal_dif_fin,"own_oppo_",TEAM_NAME_CONDITION,".csv",sep="")
input_team_info <- read.csv(input_path, header=TRUE)

###����ؕ���
#rpartmodel = rpart(BUY_INSURANCE ~ ., data = customers)
matrix_team_all_time_result_five_frame <- as.data.frame(input_team_info)
#target_team <- matrix_team_all_time_result_five_frame
library(rpart)
#rpartmodel = rpart(X.2 ~ ., data = matrix_team_all_time_result_five_frame)
rpartmodel_extracted <- matrix_team_all_time_result_five_frame[1:section,16:46]
rpartmodel = rpart(match_result ~ ., data = rpartmodel_extracted)

#rpartmodel = rpart(LOST_76_ ~ ., data = matrix_team_all_time_result_five_frame)
#rpartmodel_extracted <- matrix_team_all_time_result_five_frame[1:section,16:40]
#rpartmodel = rpart(LOST_76_ ~ ., data = rpartmodel_extracted)


#model = rpart(BUY_INSURANCE ~ ., data = customers[,-1:-7])
#model = rpart(BUY_INSURANCE ~ ., data = customers[,-1:-7], control = rpart.control(maxdepth = 4))
install.packages("rpart.plot")
library(rpart.plot)
rpart.plot(rpartmodel, extra = 4)

#��͌��ʌ���ؐ}��ۑ�
#https://stats.biopapyrus.jp/r/graph/imagedevice.html
output_path <- paste(goal_dif_fin,analysis_result_TEAM_NAME_CONDITION,".png",sep="")
png("plot1.png", width = 100, height = 100) 
rpart.plot(rpartmodel, extra = 4)
dev.off()